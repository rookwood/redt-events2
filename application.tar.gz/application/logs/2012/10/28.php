<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2012-10-28 19:30:06 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2012-10-28 19:30:06 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /home/matt/events2/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('redt_events', NULL)
#1 /home/matt/events2/system/classes/kohana/request.php(202): Kohana_Cookie::get('redt_events')
#2 /home/matt/events2/public_html/index.php(108): Kohana_Request::factory()
#3 {main}
2012-10-28 19:30:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-10-28 19:30:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}