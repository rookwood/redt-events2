<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2012-11-13 19:51:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 19:51:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 19:51:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 19:51:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 19:51:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 19:51:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 19:51:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 19:51:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 19:51:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 19:51:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 19:52:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 19:52:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 19:54:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 19:54:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 19:54:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 19:54:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 19:54:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 19:54:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 19:54:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 19:54:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:00:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:00:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:00:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:00:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:01:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:01:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:01:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:01:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:01:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:01:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:02:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/form_input_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:02:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/form_input_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:02:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:02:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:02:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:02:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:02:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:02:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:02:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:02:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:02:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:02:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:02:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:02:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:02:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:02:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:02:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:02:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:03:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:03:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:03:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:03:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:03:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:03:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:03:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:03:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:03:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:03:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:03:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:03:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:04:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:04:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:04:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:04:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:04:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/form_input_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:04:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/form_input_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:04:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:04:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:04:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:04:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:04:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:04:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:04:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:04:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:04:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:04:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:04:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:04:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:04:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:04:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:04:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:04:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:04:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:04:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:04:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:04:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:06:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:06:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:08:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:08:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:08:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:08:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:08:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:08:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:08:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:08:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:08:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:08:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:09:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:09:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:09:54 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:09:54 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:09:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:09:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:09:54 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:09:54 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:12:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:12:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:12:07 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:12:07 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:12:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:12:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:12:07 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:12:07 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:13:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:13:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:13:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:13:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:13:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:13:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:13:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:13:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:13:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:13:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:13:39 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:13:39 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:13:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:13:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:13:41 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:13:41 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:15:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:15:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:15:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:15:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:15:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:15:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:15:14 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:15:14 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:15:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:15:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:15:49 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:15:49 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:15:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:15:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:15:49 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:15:49 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:17:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:17:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:17:42 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:17:42 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:17:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:17:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:17:42 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:17:42 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:20:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:20:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:20:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:20:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:20:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:20:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:20:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:20:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:21:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:21:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:21:56 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:21:56 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:22:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:22:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:22:07 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:22:07 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:23:29 --- ERROR: ErrorException [ 1 ]: Class 'ProfilerToolbad' not found ~ APPPATH/classes/model/enrollment.php [ 92 ]
2012-11-13 20:23:29 --- STRACE: ErrorException [ 1 ]: Class 'ProfilerToolbad' not found ~ APPPATH/classes/model/enrollment.php [ 92 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:23:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:23:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:23:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:23:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:23:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:23:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:23:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:23:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:27:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:27:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:27:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:27:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:28:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:28:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:28:57 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:28:57 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:29:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:29:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:29:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:29:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:30:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:30:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:30:57 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:30:57 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:31:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:31:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:31:33 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:31:33 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:33:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:33:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:33:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:33:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:33:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:33:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:33:51 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:33:51 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:34:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:34:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:34:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:34:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:34:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:34:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:34:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:34:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:34:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:34:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:34:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:34:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:34:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:34:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:34:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:34:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:34:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:34:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:34:50 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:34:50 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:39:08 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '{' ~ APPPATH/classes/model/enrollment.php [ 88 ]
2012-11-13 20:39:08 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '{' ~ APPPATH/classes/model/enrollment.php [ 88 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:39:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:39:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:39:09 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:39:09 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:39:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:39:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:39:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:39:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:39:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:39:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:39:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:39:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:40:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:40:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:40:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:40:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:40:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:40:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:40:41 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:40:41 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:40:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:40:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:40:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:40:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:41:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:41:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:41:55 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:41:55 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-13 20:45:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-13 20:45:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-13 20:45:43 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-13 20:45:43 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}