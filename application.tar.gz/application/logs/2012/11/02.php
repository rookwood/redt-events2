<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2012-11-02 18:50:17 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2012-11-02 18:50:17 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /home/matt/events2/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('redt_events', NULL)
#1 /home/matt/events2/system/classes/kohana/request.php(202): Kohana_Cookie::get('redt_events')
#2 /home/matt/events2/public_html/index.php(108): Kohana_Request::factory()
#3 {main}
2012-11-02 18:50:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 18:50:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 18:50:17 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2012-11-02 18:50:17 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /home/matt/events2/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('redt_events', NULL)
#1 /home/matt/events2/system/classes/kohana/request.php(202): Kohana_Cookie::get('redt_events')
#2 /home/matt/events2/public_html/index.php(108): Kohana_Request::factory()
#3 {main}
2012-11-02 18:50:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 18:50:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 18:53:00 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2012-11-02 18:53:00 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /home/matt/events2/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('redt_events', NULL)
#1 /home/matt/events2/system/classes/kohana/request.php(202): Kohana_Cookie::get('redt_events')
#2 /home/matt/events2/public_html/index.php(108): Kohana_Request::factory()
#3 {main}
2012-11-02 18:53:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 18:53:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 18:53:00 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2012-11-02 18:53:00 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /home/matt/events2/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('redt_events', NULL)
#1 /home/matt/events2/system/classes/kohana/request.php(202): Kohana_Cookie::get('redt_events')
#2 /home/matt/events2/public_html/index.php(108): Kohana_Request::factory()
#3 {main}
2012-11-02 18:53:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 18:53:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 18:56:18 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2012-11-02 18:56:18 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /home/matt/events2/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('redt_events', NULL)
#1 /home/matt/events2/system/classes/kohana/request.php(202): Kohana_Cookie::get('redt_events')
#2 /home/matt/events2/public_html/index.php(108): Kohana_Request::factory()
#3 {main}
2012-11-02 18:56:19 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 18:56:19 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 18:56:19 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2012-11-02 18:56:19 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /home/matt/events2/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('redt_events', NULL)
#1 /home/matt/events2/system/classes/kohana/request.php(202): Kohana_Cookie::get('redt_events')
#2 /home/matt/events2/public_html/index.php(108): Kohana_Request::factory()
#3 {main}
2012-11-02 18:56:19 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 18:56:19 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 18:56:23 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2012-11-02 18:56:23 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /home/matt/events2/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('redt_events', NULL)
#1 /home/matt/events2/system/classes/kohana/request.php(202): Kohana_Cookie::get('redt_events')
#2 /home/matt/events2/public_html/index.php(108): Kohana_Request::factory()
#3 {main}
2012-11-02 18:56:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 18:56:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 18:56:23 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2012-11-02 18:56:23 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /home/matt/events2/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('redt_events', NULL)
#1 /home/matt/events2/system/classes/kohana/request.php(202): Kohana_Cookie::get('redt_events')
#2 /home/matt/events2/public_html/index.php(108): Kohana_Request::factory()
#3 {main}
2012-11-02 18:56:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 18:56:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 18:57:41 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2012-11-02 18:57:41 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /home/matt/events2/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('redt_events', NULL)
#1 /home/matt/events2/system/classes/kohana/request.php(202): Kohana_Cookie::get('redt_events')
#2 /home/matt/events2/public_html/index.php(108): Kohana_Request::factory()
#3 {main}
2012-11-02 18:57:41 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 18:57:41 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 18:57:41 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2012-11-02 18:57:41 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /home/matt/events2/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('redt_events', NULL)
#1 /home/matt/events2/system/classes/kohana/request.php(202): Kohana_Cookie::get('redt_events')
#2 /home/matt/events2/public_html/index.php(108): Kohana_Request::factory()
#3 {main}
2012-11-02 18:57:41 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 18:57:41 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 18:57:58 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2012-11-02 18:57:58 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /home/matt/events2/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('redt_events', NULL)
#1 /home/matt/events2/system/classes/kohana/request.php(202): Kohana_Cookie::get('redt_events')
#2 /home/matt/events2/public_html/index.php(108): Kohana_Request::factory()
#3 {main}
2012-11-02 18:57:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 18:57:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 18:57:58 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2012-11-02 18:57:58 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /home/matt/events2/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('redt_events', NULL)
#1 /home/matt/events2/system/classes/kohana/request.php(202): Kohana_Cookie::get('redt_events')
#2 /home/matt/events2/public_html/index.php(108): Kohana_Request::factory()
#3 {main}
2012-11-02 18:57:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 18:57:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 18:58:47 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2012-11-02 18:58:47 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /home/matt/events2/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('redt_events', NULL)
#1 /home/matt/events2/system/classes/kohana/request.php(202): Kohana_Cookie::get('redt_events')
#2 /home/matt/events2/public_html/index.php(108): Kohana_Request::factory()
#3 {main}
2012-11-02 18:58:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 18:58:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 18:58:47 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2012-11-02 18:58:47 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /home/matt/events2/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('redt_events', NULL)
#1 /home/matt/events2/system/classes/kohana/request.php(202): Kohana_Cookie::get('redt_events')
#2 /home/matt/events2/public_html/index.php(108): Kohana_Request::factory()
#3 {main}
2012-11-02 18:58:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 18:58:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 18:59:14 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2012-11-02 18:59:14 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /home/matt/events2/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('redt_events', NULL)
#1 /home/matt/events2/system/classes/kohana/request.php(202): Kohana_Cookie::get('redt_events')
#2 /home/matt/events2/public_html/index.php(108): Kohana_Request::factory()
#3 {main}
2012-11-02 18:59:14 --- ERROR: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
2012-11-02 18:59:14 --- STRACE: Kohana_Exception [ 0 ]: A valid cookie salt is required. Please set Cookie::$salt. ~ SYSPATH/classes/kohana/cookie.php [ 152 ]
--
#0 /home/matt/events2/system/classes/kohana/cookie.php(67): Kohana_Cookie::salt('redt_events', NULL)
#1 /home/matt/events2/system/classes/kohana/request.php(202): Kohana_Cookie::get('redt_events')
#2 /home/matt/events2/public_html/index.php(108): Kohana_Request::factory()
#3 {main}
2012-11-02 19:01:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 19:01:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 19:01:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 19:01:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 19:01:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 19:01:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 19:05:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 19:05:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 19:05:03 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 19:05:03 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 19:05:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 19:05:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 19:05:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 19:05:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:44:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:44:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:44:47 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '}' ~ APPPATH/classes/abstract/controller/website.php [ 44 ]
2012-11-02 21:44:47 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '}' ~ APPPATH/classes/abstract/controller/website.php [ 44 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:44:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:44:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:45:52 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_IF ~ APPPATH/classes/abstract/controller/website.php [ 83 ]
2012-11-02 21:45:52 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_IF ~ APPPATH/classes/abstract/controller/website.php [ 83 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:45:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:45:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:46:11 --- ERROR: ErrorException [ 2048 ]: Declaration of Model_User::create_user() should be compatible with that of Model_Auth_User::create_user() ~ APPPATH/classes/model/user.php [ 7 ]
2012-11-02 21:46:11 --- STRACE: ErrorException [ 2048 ]: Declaration of Model_User::create_user() should be compatible with that of Model_Auth_User::create_user() ~ APPPATH/classes/model/user.php [ 7 ]
--
#0 /home/matt/events2/application/classes/model/user.php(7): Kohana_Core::error_handler(2048, 'Declaration of ...', '/home/matt/even...', 7, Array)
#1 /home/matt/events2/system/classes/kohana/core.php(504): require('/home/matt/even...')
#2 [internal function]: Kohana_Core::auto_load('Model_User')
#3 /home/matt/events2/application/classes/auth.php(26): spl_autoload_call('Model_User')
#4 /home/matt/events2/modules/orm/classes/kohana/auth/orm.php(190): Auth->get_user(NULL)
#5 /home/matt/events2/modules/orm/classes/kohana/auth/orm.php(21): Kohana_Auth_ORM->get_user()
#6 /home/matt/events2/application/classes/abstract/controller/website.php(18): Kohana_Auth_ORM->logged_in()
#7 [internal function]: Abstract_Controller_Website->before()
#8 /home/matt/events2/system/classes/kohana/request/client/internal.php(103): ReflectionMethod->invoke(Object(Controller_Static))
#9 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#11 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#12 {main}
2012-11-02 21:46:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:46:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:50:33 --- ERROR: ErrorException [ 2048 ]: Declaration of Model_User::create() should be compatible with that of Kohana_ORM::create() ~ APPPATH/classes/model/user.php [ 7 ]
2012-11-02 21:50:33 --- STRACE: ErrorException [ 2048 ]: Declaration of Model_User::create() should be compatible with that of Kohana_ORM::create() ~ APPPATH/classes/model/user.php [ 7 ]
--
#0 /home/matt/events2/application/classes/model/user.php(7): Kohana_Core::error_handler(2048, 'Declaration of ...', '/home/matt/even...', 7, Array)
#1 /home/matt/events2/system/classes/kohana/core.php(504): require('/home/matt/even...')
#2 [internal function]: Kohana_Core::auto_load('Model_User')
#3 /home/matt/events2/application/classes/auth.php(26): spl_autoload_call('Model_User')
#4 /home/matt/events2/modules/orm/classes/kohana/auth/orm.php(190): Auth->get_user(NULL)
#5 /home/matt/events2/modules/orm/classes/kohana/auth/orm.php(21): Kohana_Auth_ORM->get_user()
#6 /home/matt/events2/application/classes/abstract/controller/website.php(18): Kohana_Auth_ORM->logged_in()
#7 [internal function]: Abstract_Controller_Website->before()
#8 /home/matt/events2/system/classes/kohana/request/client/internal.php(103): ReflectionMethod->invoke(Object(Controller_Static))
#9 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#11 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#12 {main}
2012-11-02 21:50:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:50:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:51:00 --- ERROR: Kohana_Exception [ 0 ]: There was no View created for this request. ~ APPPATH/classes/abstract/controller/website.php [ 77 ]
2012-11-02 21:51:00 --- STRACE: Kohana_Exception [ 0 ]: There was no View created for this request. ~ APPPATH/classes/abstract/controller/website.php [ 77 ]
--
#0 [internal function]: Abstract_Controller_Website->after()
#1 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Static))
#2 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#4 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#5 {main}
2012-11-02 21:51:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:51:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:51:24 --- ERROR: Kohana_Exception [ 0 ]: There was no View created for this request. ~ APPPATH/classes/abstract/controller/website.php [ 77 ]
2012-11-02 21:51:24 --- STRACE: Kohana_Exception [ 0 ]: There was no View created for this request. ~ APPPATH/classes/abstract/controller/website.php [ 77 ]
--
#0 [internal function]: Abstract_Controller_Website->after()
#1 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Static))
#2 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#4 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#5 {main}
2012-11-02 21:51:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:51:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:51:24 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:51:24 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:53:10 --- ERROR: Kohana_Exception [ 0 ]: Template file does not exist: templates/layout/boilerplate ~ MODPATH/kostache/classes/kohana/kostache.php [ 244 ]
2012-11-02 21:53:10 --- STRACE: Kohana_Exception [ 0 ]: Template file does not exist: templates/layout/boilerplate ~ MODPATH/kostache/classes/kohana/kostache.php [ 244 ]
--
#0 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(41): Kohana_Kostache->_load('layout/boilerpl...')
#1 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#2 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#3 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#4 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Static_News))
#5 [internal function]: Abstract_Controller_Website->after()
#6 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Static))
#7 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#10 {main}
2012-11-02 21:53:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:53:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:53:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:53:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:53:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:53:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:53:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:53:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:53:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:53:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:53:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:53:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:53:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:53:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:53:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:53:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:53:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:53:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:53:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:53:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:53:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:53:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:53:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:53:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:53:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:53:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:53:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:53:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:54:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:54:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:54:09 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:54:09 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:54:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:54:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:54:09 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:54:09 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:54:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:54:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:54:09 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:54:09 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:54:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:54:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:54:09 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:54:09 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:54:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:54:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:54:09 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:54:09 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:54:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:54:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:54:09 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:54:09 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:54:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:54:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:54:09 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:54:09 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:54:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:54:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:54:09 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:54:09 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:54:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:54:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:54:09 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:54:09 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:55:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:55:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:55:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:55:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:55:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:55:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:55:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:55:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:55:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:55:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:55:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:55:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:55:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:55:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:55:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:55:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:55:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:55:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:55:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:55:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:55:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:55:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:55:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:55:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:55:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:55:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:55:22 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:55:22 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:56:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:56:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:56:15 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:56:15 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:56:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:56:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:56:15 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:56:15 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:56:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:56:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:56:15 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:56:15 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:56:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:56:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:56:15 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:56:15 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:56:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:56:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:56:15 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:56:15 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:56:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:56:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:56:15 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:56:15 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:56:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:56:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:56:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:56:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:58:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:58:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:58:31 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:58:31 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:58:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:58:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:58:31 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:58:31 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:58:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:58:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:58:31 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:58:31 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:58:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:58:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:58:31 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:58:31 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:58:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:58:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:58:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:58:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:58:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:58:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:58:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:58:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:58:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:58:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:58:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:58:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:58:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:58:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:58:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:58:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:58:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:58:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:58:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:58:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:58:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:58:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:58:37 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:58:37 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:58:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:58:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:58:37 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:58:37 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:58:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:58:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:58:37 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:58:37 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:58:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:58:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:58:37 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:58:37 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 21:58:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 21:58:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 21:58:37 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 21:58:37 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:00:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:00:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:00:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:00:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:00:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:00:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:00:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:00:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:00:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:00:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:00:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:00:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:00:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:00:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:00:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:00:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:00:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:00:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:00:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:00:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:00:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:00:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:00:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:00:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:00:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:00:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:00:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:00:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:19:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:19:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:19:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:19:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:19:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:19:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:19:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:19:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:19:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:19:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:19:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:19:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:19:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:19:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:19:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:19:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:19:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:19:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:19:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:19:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:19:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:19:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:19:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:19:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:19:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:19:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:19:24 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:19:24 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:19:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:19:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:19:24 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:19:24 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:19:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:19:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:19:24 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:19:24 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:19:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:19:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:19:46 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:19:46 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:19:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:19:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:19:52 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:19:52 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:22:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:22:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:24:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:24:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:25:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:25:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:25:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:25:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:25:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:25:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:25:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:25:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:25:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:25:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:25:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:25:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:26:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:26:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:26:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:26:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:26:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:26:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:26:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:26:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:26:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:26:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:26:48 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:26:48 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:26:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:26:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:26:48 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:26:48 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:26:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:26:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:26:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:26:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:26:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:26:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:26:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:26:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:28:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:28:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:28:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:28:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:28:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:28:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:28:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:28:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:29:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:29:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:29:04 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:29:04 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:29:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:29:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:29:04 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:29:04 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:29:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:29:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:29:14 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:29:14 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:29:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:29:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:29:14 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:29:14 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:30:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: events ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:30:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: events ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:30:22 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:30:22 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:30:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:30:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:30:22 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:30:22 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:37:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:37:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:37:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:37:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:37:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:37:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:37:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:37:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:42:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:42:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:42:53 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:42:53 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:45:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:45:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:45:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:45:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:45:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:45:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:45:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:45:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:45:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:45:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:45:42 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:45:42 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:48:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:48:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:48:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:48:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:48:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:48:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:48:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:48:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:50:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:50:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:50:04 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:50:04 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:50:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:50:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:50:04 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:50:04 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:50:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:50:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:50:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:50:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:50:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:50:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:50:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:50:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:51:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:51:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:51:33 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:51:33 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:51:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:51:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:51:33 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:51:33 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:51:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:51:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:51:42 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:51:42 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:51:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:51:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:51:42 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:51:42 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:59:21 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_RETURN, expecting T_FUNCTION ~ APPPATH/classes/abstract/view/page.php [ 140 ]
2012-11-02 22:59:21 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_RETURN, expecting T_FUNCTION ~ APPPATH/classes/abstract/view/page.php [ 140 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:59:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:59:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:59:22 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:59:22 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 22:59:44 --- ERROR: Kohana_Exception [ 0 ]: The requested route does not exist: event ~ SYSPATH/classes/kohana/route.php [ 106 ]
2012-11-02 22:59:44 --- STRACE: Kohana_Exception [ 0 ]: The requested route does not exist: event ~ SYSPATH/classes/kohana/route.php [ 106 ]
--
#0 /home/matt/events2/system/classes/kohana/route.php(202): Kohana_Route::get('event')
#1 /home/matt/events2/application/classes/abstract/view/page.php(91): Kohana_Route::url('event')
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): Abstract_View_Page->links()
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('links', Array)
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('links')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<nav>???<ul>??{...', Array)
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('<nav>???<ul>??{...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('main_navigation', NULL, '????')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'main_navigation', NULL, '????')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(266): Mustache->_renderTags('<!DOCTYPE html>...')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!DOCTYPE html>...', Array)
#11 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#12 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#13 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#14 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#15 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Static_News))
#16 [internal function]: Abstract_Controller_Website->after()
#17 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Static))
#18 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#19 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#20 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#21 {main}
2012-11-02 22:59:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 22:59:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 22:59:44 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 22:59:44 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 23:01:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 23:01:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 23:01:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 23:01:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 23:01:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 23:01:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 23:01:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 23:01:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 23:02:03 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/controller/user.php [ 316 ]
2012-11-02 23:02:03 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/controller/user.php [ 316 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 23:02:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 23:02:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 23:02:03 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 23:02:03 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 23:02:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 23:02:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 23:02:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 23:02:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 23:02:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 23:02:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 23:02:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 23:02:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 23:02:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 23:02:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 23:02:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 23:02:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 23:02:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 23:02:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 23:02:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 23:02:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 23:02:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 23:02:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 23:02:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 23:02:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 23:02:14 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_VARIABLE ~ APPPATH/classes/model/event.php [ 84 ]
2012-11-02 23:02:14 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_VARIABLE ~ APPPATH/classes/model/event.php [ 84 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 23:02:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 23:02:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 23:02:14 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 23:02:14 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-02 23:02:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-02 23:02:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-02 23:02:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-02 23:02:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}