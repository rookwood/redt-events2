<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2012-11-06 11:26:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:26:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:26:14 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:26:14 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:26:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:26:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:26:16 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:26:16 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:26:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:26:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:26:24 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:26:24 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:26:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:26:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:26:25 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:26:25 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:26:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:26:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:26:33 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:26:33 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:26:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:26:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:26:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:26:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:27:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:27:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:27:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:27:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:27:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:27:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:27:31 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:27:31 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:27:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:27:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:27:50 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:27:50 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:27:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:27:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:27:56 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:27:56 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:29:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:29:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:29:16 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:29:16 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:29:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:29:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:29:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:29:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:29:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:29:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:29:19 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:29:19 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:29:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
2012-11-06 11:29:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
--
#0 /home/matt/events2/application/classes/abstract/view/page.php(196): Kohana_Core::error_handler(8, 'Trying to get p...', '/home/matt/even...', 196, Array)
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): Abstract_View_Page->timezone_list()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('timezone_list', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('timezone_list')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('" {{#errors.pla...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{^values.playe...')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#location_...')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#14 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#15 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#16 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(213): Mustache->render()
#17 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(34): Kohana_Kostache->render()
#18 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#19 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#20 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#21 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Edit))
#22 [internal function]: Abstract_Controller_Website->after()
#23 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#24 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#25 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#26 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#27 {main}
2012-11-06 11:29:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:29:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:29:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:29:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:29:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:29:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:29:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:29:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:29:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:29:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:29:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:29:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:29:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:29:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:29:57 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:29:57 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:30:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:30:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:30:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:30:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:30:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:30:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:30:02 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:30:02 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:30:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:30:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:30:07 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:30:07 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:30:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:30:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:30:16 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:30:16 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:30:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:30:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:30:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:30:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:30:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:30:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:30:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:30:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:30:31 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:30:31 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:30:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:30:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:30:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:30:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:30:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:30:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:30:34 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:30:34 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:30:34 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
2012-11-06 11:30:34 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
--
#0 /home/matt/events2/application/classes/abstract/view/page.php(196): Kohana_Core::error_handler(8, 'Trying to get p...', '/home/matt/even...', 196, Array)
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): Abstract_View_Page->timezone_list()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('timezone_list', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('timezone_list')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('" {{#errors.pla...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{^values.playe...')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#location_...')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#14 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#15 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#16 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(213): Mustache->render()
#17 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(34): Kohana_Kostache->render()
#18 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#19 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#20 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#21 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Edit))
#22 [internal function]: Abstract_Controller_Website->after()
#23 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#24 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#25 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#26 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#27 {main}
2012-11-06 11:30:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:30:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:30:37 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:30:37 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:30:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:30:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:30:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:30:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:30:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:30:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:30:41 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:30:41 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:30:41 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
2012-11-06 11:30:41 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
--
#0 /home/matt/events2/application/classes/abstract/view/page.php(196): Kohana_Core::error_handler(8, 'Trying to get p...', '/home/matt/even...', 196, Array)
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): Abstract_View_Page->timezone_list()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('timezone_list', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('timezone_list')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('" {{#errors.pla...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{^values.playe...')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#location_...')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#14 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#15 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#16 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(213): Mustache->render()
#17 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(34): Kohana_Kostache->render()
#18 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#19 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#20 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#21 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Edit))
#22 [internal function]: Abstract_Controller_Website->after()
#23 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#24 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#25 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#26 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#27 {main}
2012-11-06 11:30:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:30:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:30:57 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:30:57 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:31:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:31:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:31:53 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:31:53 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:31:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:31:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:31:55 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:31:55 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:31:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:31:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:31:56 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:31:56 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:31:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
2012-11-06 11:31:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
--
#0 /home/matt/events2/application/classes/abstract/view/page.php(196): Kohana_Core::error_handler(8, 'Trying to get p...', '/home/matt/even...', 196, Array)
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): Abstract_View_Page->timezone_list()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('timezone_list', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('timezone_list')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('" {{#errors.pla...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{^values.playe...')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#location_...')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#14 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#15 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#16 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(213): Mustache->render()
#17 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(34): Kohana_Kostache->render()
#18 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#19 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#20 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#21 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Edit))
#22 [internal function]: Abstract_Controller_Website->after()
#23 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#24 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#25 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#26 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#27 {main}
2012-11-06 11:32:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:32:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:32:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:32:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:32:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:32:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:32:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:32:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:33:04 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
2012-11-06 11:33:04 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
--
#0 /home/matt/events2/application/classes/abstract/view/page.php(196): Kohana_Core::error_handler(8, 'Trying to get p...', '/home/matt/even...', 196, Array)
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): Abstract_View_Page->timezone_list()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('timezone_list', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('timezone_list')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('" {{#errors.pla...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{^values.playe...')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#location_...')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#14 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#15 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#16 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(213): Mustache->render()
#17 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(34): Kohana_Kostache->render()
#18 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#19 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#20 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#21 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Edit))
#22 [internal function]: Abstract_Controller_Website->after()
#23 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#24 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#25 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#26 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#27 {main}
2012-11-06 11:33:05 --- ERROR: ErrorException [ 1 ]: Class 'ProfilerToolbar' not found ~ APPPATH/classes/abstract/view/page.php [ 179 ]
2012-11-06 11:33:05 --- STRACE: ErrorException [ 1 ]: Class 'ProfilerToolbar' not found ~ APPPATH/classes/abstract/view/page.php [ 179 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:33:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:33:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:33:07 --- ERROR: ErrorException [ 1 ]: Class 'ProfilerToolbar' not found ~ APPPATH/classes/abstract/view/page.php [ 179 ]
2012-11-06 11:33:07 --- STRACE: ErrorException [ 1 ]: Class 'ProfilerToolbar' not found ~ APPPATH/classes/abstract/view/page.php [ 179 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:33:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:33:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:34:48 --- ERROR: ErrorException [ 1 ]: Class 'ProfilerToolbar' not found ~ APPPATH/classes/abstract/view/page.php [ 179 ]
2012-11-06 11:34:48 --- STRACE: ErrorException [ 1 ]: Class 'ProfilerToolbar' not found ~ APPPATH/classes/abstract/view/page.php [ 179 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:34:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:34:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:35:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:35:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:35:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:35:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:35:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:35:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:35:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:35:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:35:34 --- ERROR: ErrorException [ 1 ]: Class 'ProfilerToolbar' not found ~ APPPATH/classes/view/page/event/display.php [ 65 ]
2012-11-06 11:35:34 --- STRACE: ErrorException [ 1 ]: Class 'ProfilerToolbar' not found ~ APPPATH/classes/view/page/event/display.php [ 65 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:35:36 --- ERROR: ErrorException [ 1 ]: Class 'ProfilerToolbar' not found ~ APPPATH/classes/view/page/event/display.php [ 65 ]
2012-11-06 11:35:36 --- STRACE: ErrorException [ 1 ]: Class 'ProfilerToolbar' not found ~ APPPATH/classes/view/page/event/display.php [ 65 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:35:37 --- ERROR: ErrorException [ 1 ]: Class 'ProfilerToolbar' not found ~ APPPATH/classes/view/page/event/display.php [ 65 ]
2012-11-06 11:35:37 --- STRACE: ErrorException [ 1 ]: Class 'ProfilerToolbar' not found ~ APPPATH/classes/view/page/event/display.php [ 65 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:35:38 --- ERROR: ErrorException [ 1 ]: Class 'ProfilerToolbar' not found ~ APPPATH/classes/view/page/event/display.php [ 65 ]
2012-11-06 11:35:38 --- STRACE: ErrorException [ 1 ]: Class 'ProfilerToolbar' not found ~ APPPATH/classes/view/page/event/display.php [ 65 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:36:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:36:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:36:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:36:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:36:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:36:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:36:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:36:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:36:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
2012-11-06 11:36:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
--
#0 /home/matt/events2/application/classes/abstract/view/page.php(196): Kohana_Core::error_handler(8, 'Trying to get p...', '/home/matt/even...', 196, Array)
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): Abstract_View_Page->timezone_list()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('timezone_list', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('timezone_list')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('" {{#errors.pla...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{^values.playe...')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#location_...')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#14 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#15 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#16 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(213): Mustache->render()
#17 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(34): Kohana_Kostache->render()
#18 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#19 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#20 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#21 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Edit))
#22 [internal function]: Abstract_Controller_Website->after()
#23 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#24 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#25 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#26 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#27 {main}
2012-11-06 11:36:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:36:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:36:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
2012-11-06 11:36:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
--
#0 /home/matt/events2/application/classes/abstract/view/page.php(196): Kohana_Core::error_handler(8, 'Trying to get p...', '/home/matt/even...', 196, Array)
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): Abstract_View_Page->timezone_list()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('timezone_list', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('timezone_list')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('" {{#errors.pla...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{^values.playe...')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#location_...')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#14 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#15 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#16 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(213): Mustache->render()
#17 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(34): Kohana_Kostache->render()
#18 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#19 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#20 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#21 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Edit))
#22 [internal function]: Abstract_Controller_Website->after()
#23 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#24 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#25 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#26 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#27 {main}
2012-11-06 11:37:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:37:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:37:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:37:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:37:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:37:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:37:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:37:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:39:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:39:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:39:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:39:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:39:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:39:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:39:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:39:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:39:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
2012-11-06 11:39:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
--
#0 /home/matt/events2/application/classes/abstract/view/page.php(196): Kohana_Core::error_handler(8, 'Trying to get p...', '/home/matt/even...', 196, Array)
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): Abstract_View_Page->timezone_list()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('timezone_list', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('timezone_list')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('" {{#errors.pla...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{^values.playe...')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#location_...')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#14 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#15 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#16 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(213): Mustache->render()
#17 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(34): Kohana_Kostache->render()
#18 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#19 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#20 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#21 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Edit))
#22 [internal function]: Abstract_Controller_Website->after()
#23 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#24 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#25 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#26 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#27 {main}
2012-11-06 11:39:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:39:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:40:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:40:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:40:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:40:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:40:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:40:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:40:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:40:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:40:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:40:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:40:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:40:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:40:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:40:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:40:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:40:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:40:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
2012-11-06 11:40:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
--
#0 /home/matt/events2/application/classes/abstract/view/page.php(196): Kohana_Core::error_handler(8, 'Trying to get p...', '/home/matt/even...', 196, Array)
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): Abstract_View_Page->timezone_list()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('timezone_list', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('timezone_list')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('" {{#errors.pla...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{^values.playe...')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#location_...')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#14 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#15 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#16 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(213): Mustache->render()
#17 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(34): Kohana_Kostache->render()
#18 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#19 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#20 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#21 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Edit))
#22 [internal function]: Abstract_Controller_Website->after()
#23 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#24 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#25 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#26 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#27 {main}
2012-11-06 11:41:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:41:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:41:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:41:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:41:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:41:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:41:25 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
2012-11-06 11:41:25 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
--
#0 /home/matt/events2/application/classes/abstract/view/page.php(196): Kohana_Core::error_handler(8, 'Trying to get p...', '/home/matt/even...', 196, Array)
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): Abstract_View_Page->timezone_list()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('timezone_list', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('timezone_list')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('" {{#errors.pla...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{^values.playe...')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#location_...')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#14 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#15 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#16 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(213): Mustache->render()
#17 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(34): Kohana_Kostache->render()
#18 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#19 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#20 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#21 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Edit))
#22 [internal function]: Abstract_Controller_Website->after()
#23 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#24 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#25 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#26 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#27 {main}
2012-11-06 11:41:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:41:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:41:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:41:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:41:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:41:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:43:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
2012-11-06 11:43:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
--
#0 /home/matt/events2/application/classes/abstract/view/page.php(196): Kohana_Core::error_handler(8, 'Trying to get p...', '/home/matt/even...', 196, Array)
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): Abstract_View_Page->timezone_list()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('timezone_list', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('timezone_list')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('" {{#errors.pla...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{^values.playe...')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#location_...')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#14 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#15 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#16 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(213): Mustache->render()
#17 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(34): Kohana_Kostache->render()
#18 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#19 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#20 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#21 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Edit))
#22 [internal function]: Abstract_Controller_Website->after()
#23 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#24 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#25 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#26 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#27 {main}
2012-11-06 11:43:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:43:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:44:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:44:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:44:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:44:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:44:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:44:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:44:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:44:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:45:02 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
2012-11-06 11:45:02 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
--
#0 /home/matt/events2/application/classes/abstract/view/page.php(196): Kohana_Core::error_handler(8, 'Trying to get p...', '/home/matt/even...', 196, Array)
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): Abstract_View_Page->timezone_list()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('timezone_list', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('timezone_list')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('" {{#errors.pla...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{^values.playe...')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#location_...')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#14 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#15 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#16 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(213): Mustache->render()
#17 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(34): Kohana_Kostache->render()
#18 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#19 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#20 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#21 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Edit))
#22 [internal function]: Abstract_Controller_Website->after()
#23 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#24 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#25 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#26 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#27 {main}
2012-11-06 11:45:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:45:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:45:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:45:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:45:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:45:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:45:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:45:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:45:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:45:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:45:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:45:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:45:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:45:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:45:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:45:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:45:26 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
2012-11-06 11:45:26 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
--
#0 /home/matt/events2/application/classes/abstract/view/page.php(196): Kohana_Core::error_handler(8, 'Trying to get p...', '/home/matt/even...', 196, Array)
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): Abstract_View_Page->timezone_list()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('timezone_list', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('timezone_list')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('" {{#errors.pla...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{^values.playe...')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#location_...')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#14 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#15 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#16 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(213): Mustache->render()
#17 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(34): Kohana_Kostache->render()
#18 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#19 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#20 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#21 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Edit))
#22 [internal function]: Abstract_Controller_Website->after()
#23 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#24 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#25 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#26 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#27 {main}
2012-11-06 11:46:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:46:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:46:58 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/view/page/event/edit.php [ 17 ]
2012-11-06 11:46:58 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/view/page/event/edit.php [ 17 ]
--
#0 /home/matt/events2/application/classes/view/page/event/edit.php(17): Kohana_Core::error_handler(8, 'Trying to get p...', '/home/matt/even...', 17, Array)
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Edit->scheduled_time()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('scheduled_time', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(655): Mustache->_getVariable('scheduled_time')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(622): Mustache->_renderUnescaped('scheduled_time', '', '')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(590): Mustache->_renderEscaped('scheduled_time', NULL, NULL)
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('', 'scheduled_time', NULL, NULL)
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??????</li>????...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('" {{#errors.pla...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{^values.playe...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#14 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#location_...')
#15 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#16 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#17 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#18 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(213): Mustache->render()
#19 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(34): Kohana_Kostache->render()
#20 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#21 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#22 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#23 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Edit))
#24 [internal function]: Abstract_Controller_Website->after()
#25 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#26 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#27 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#28 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#29 {main}
2012-11-06 11:47:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:47:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:47:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:47:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:47:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:47:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:47:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:47:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:47:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:47:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:47:15 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/view/page/event/edit.php [ 17 ]
2012-11-06 11:47:15 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/view/page/event/edit.php [ 17 ]
--
#0 /home/matt/events2/application/classes/view/page/event/edit.php(17): Kohana_Core::error_handler(8, 'Trying to get p...', '/home/matt/even...', 17, Array)
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Edit->scheduled_time()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('scheduled_time', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(655): Mustache->_getVariable('scheduled_time')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(622): Mustache->_renderUnescaped('scheduled_time', '', '')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(590): Mustache->_renderEscaped('scheduled_time', NULL, NULL)
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('', 'scheduled_time', NULL, NULL)
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??????</li>????...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('" {{#errors.pla...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{^values.playe...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#14 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#location_...')
#15 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#16 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#17 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#18 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(213): Mustache->render()
#19 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(34): Kohana_Kostache->render()
#20 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#21 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#22 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#23 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Edit))
#24 [internal function]: Abstract_Controller_Website->after()
#25 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#26 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#27 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#28 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#29 {main}
2012-11-06 11:47:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:47:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:47:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:47:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:49:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:49:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:49:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:49:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:49:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:49:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:49:09 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
2012-11-06 11:49:09 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
--
#0 /home/matt/events2/application/classes/abstract/view/page.php(196): Kohana_Core::error_handler(8, 'Trying to get p...', '/home/matt/even...', 196, Array)
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): Abstract_View_Page->timezone_list()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('timezone_list', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('timezone_list')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('" {{#errors.pla...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{^values.playe...')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#location_...')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#14 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#15 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#16 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(213): Mustache->render()
#17 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(34): Kohana_Kostache->render()
#18 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#19 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#20 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#21 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Edit))
#22 [internal function]: Abstract_Controller_Website->after()
#23 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#24 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#25 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#26 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#27 {main}
2012-11-06 11:49:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:49:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:49:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:49:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:49:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:49:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:49:27 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
2012-11-06 11:49:27 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/abstract/view/page.php [ 196 ]
--
#0 /home/matt/events2/application/classes/abstract/view/page.php(196): Kohana_Core::error_handler(8, 'Trying to get p...', '/home/matt/even...', 196, Array)
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): Abstract_View_Page->timezone_list()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('timezone_list', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('timezone_list')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('" {{#errors.pla...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{^values.playe...')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#location_...')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#14 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#15 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#16 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(213): Mustache->render()
#17 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(34): Kohana_Kostache->render()
#18 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#19 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#20 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#21 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Edit))
#22 [internal function]: Abstract_Controller_Website->after()
#23 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#24 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#25 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#26 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#27 {main}
2012-11-06 11:50:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:50:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:50:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:50:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:50:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:50:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:50:51 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/view/page/event/edit.php [ 17 ]
2012-11-06 11:50:51 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/view/page/event/edit.php [ 17 ]
--
#0 /home/matt/events2/application/classes/view/page/event/edit.php(17): Kohana_Core::error_handler(8, 'Trying to get p...', '/home/matt/even...', 17, Array)
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Edit->scheduled_time()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('scheduled_time', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(655): Mustache->_getVariable('scheduled_time')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(622): Mustache->_renderUnescaped('scheduled_time', '', '')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(590): Mustache->_renderEscaped('scheduled_time', NULL, NULL)
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('', 'scheduled_time', NULL, NULL)
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??????</li>????...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('" {{#errors.pla...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('{{^values.playe...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????</select...')
#14 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#location_...')
#15 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#16 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#17 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#18 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(213): Mustache->render()
#19 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(34): Kohana_Kostache->render()
#20 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#21 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#22 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#23 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Edit))
#24 [internal function]: Abstract_Controller_Website->after()
#25 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#26 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#27 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#28 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#29 {main}
2012-11-06 11:50:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:50:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:58:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:58:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:58:55 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:58:55 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 11:59:14 --- ERROR: ErrorException [ 8 ]: Undefined variable: user ~ APPPATH/classes/model/event.php [ 118 ]
2012-11-06 11:59:14 --- STRACE: ErrorException [ 8 ]: Undefined variable: user ~ APPPATH/classes/model/event.php [ 118 ]
--
#0 /home/matt/events2/application/classes/model/event.php(118): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/matt/even...', 118, Array)
#1 /home/matt/events2/application/classes/controller/event.php(120): Model_Event->edit_event(Array)
#2 [internal function]: Controller_Event->action_edit()
#3 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#4 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-11-06 11:59:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 11:59:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 11:59:15 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 11:59:15 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 12:01:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 12:01:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 12:01:04 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 12:01:04 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 12:01:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 12:01:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 12:01:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 12:01:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 12:01:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 12:01:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 12:01:14 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 12:01:14 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 12:01:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 12:01:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 12:01:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 12:01:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 12:01:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 12:01:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 12:01:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 12:01:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 12:28:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 12:28:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 12:28:54 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 12:28:54 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 12:29:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 12:29:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 12:29:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 12:29:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 12:29:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 12:29:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 12:29:03 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 12:29:03 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 12:29:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 12:29:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 12:29:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 12:29:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 12:29:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 12:29:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 12:29:07 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 12:29:07 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 12:29:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 12:29:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 12:29:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 12:29:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 12:29:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 12:29:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 12:29:09 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 12:29:09 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 12:30:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 12:30:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 12:30:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 12:30:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 12:30:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 12:30:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 12:30:02 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 12:30:02 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 12:30:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 12:30:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 12:30:34 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 12:30:34 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:44:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:44:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:44:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:44:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:44:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:44:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:44:35 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:44:35 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:44:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:44:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:44:43 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:44:43 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:44:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:44:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:44:52 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:44:52 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:45:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:45:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:45:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:45:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:45:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:45:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:45:07 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:45:07 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:48:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:48:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:48:53 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:48:53 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:48:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:48:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:48:54 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:48:54 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:49:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:49:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:49:19 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:49:19 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:49:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:49:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:49:54 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:49:54 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:51:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:51:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:51:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:51:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:52:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:52:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:52:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:52:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:52:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:52:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:52:13 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:52:13 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:54:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:54:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:54:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:54:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:54:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:54:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:54:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:54:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:54:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:54:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:54:28 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:54:28 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:54:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:54:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:54:31 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:54:31 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:54:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:54:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:54:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:54:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:54:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:54:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:54:42 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:54:42 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:54:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:54:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:54:43 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:54:43 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:54:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:54:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:54:55 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:54:55 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:54:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:54:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:54:56 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:54:56 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:55:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:55:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:55:03 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:55:03 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:55:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:55:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:55:03 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:55:03 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:58:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:58:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:58:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:58:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 17:58:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 17:58:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-06 17:58:35 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 17:58:35 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 18:01:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 18:01:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(111): Kohana_Request->execute()
#1 {main}
2012-11-06 18:01:46 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 18:01:46 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 18:02:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 18:02:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(111): Kohana_Request->execute()
#1 {main}
2012-11-06 18:02:56 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 18:02:56 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 18:05:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 18:05:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-06 18:05:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 18:05:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 18:06:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 18:06:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-06 18:06:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 18:06:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 18:07:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 18:07:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-06 18:07:50 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 18:07:50 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 18:07:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 18:07:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-06 18:07:53 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 18:07:53 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 18:07:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 18:07:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-06 18:07:59 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 18:07:59 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 18:08:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 18:08:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-06 18:08:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 18:08:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 18:08:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 18:08:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-06 18:08:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 18:08:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 18:20:56 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '{' ~ APPPATH/classes/abstract/view/page.php [ 132 ]
2012-11-06 18:20:56 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '{' ~ APPPATH/classes/abstract/view/page.php [ 132 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 18:20:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 18:20:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-06 18:20:56 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 18:20:56 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 18:21:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 18:21:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-06 18:21:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 18:21:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 18:21:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 18:21:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-06 18:21:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 18:21:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-06 18:21:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-06 18:21:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-06 18:21:25 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-06 18:21:25 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}