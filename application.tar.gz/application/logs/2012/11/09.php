<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2012-11-09 17:07:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:07:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:07:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:07:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:08:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:08:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:08:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:08:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:08:24 --- ERROR: ErrorException [ 1 ]: Call to a member function can() on a non-object ~ APPPATH/classes/view/page/event/index.php [ 54 ]
2012-11-09 17:08:24 --- STRACE: ErrorException [ 1 ]: Call to a member function can() on a non-object ~ APPPATH/classes/view/page/event/index.php [ 54 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:08:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:08:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:08:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:08:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:09:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:09:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:09:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:09:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:12:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:12:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:12:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:12:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:12:09 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/model/event.php [ 356 ]
2012-11-09 17:12:09 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/model/event.php [ 356 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:12:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:12:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:12:09 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:12:09 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:12:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:12:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:12:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:12:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:12:23 --- ERROR: ErrorException [ 1 ]: Call to a member function can() on a non-object ~ APPPATH/classes/view/page/event/index.php [ 54 ]
2012-11-09 17:12:23 --- STRACE: ErrorException [ 1 ]: Call to a member function can() on a non-object ~ APPPATH/classes/view/page/event/index.php [ 54 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:12:24 --- ERROR: ErrorException [ 1 ]: Call to a member function can() on a non-object ~ APPPATH/classes/view/page/event/index.php [ 54 ]
2012-11-09 17:12:24 --- STRACE: ErrorException [ 1 ]: Call to a member function can() on a non-object ~ APPPATH/classes/view/page/event/index.php [ 54 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:12:24 --- ERROR: ErrorException [ 1 ]: Call to a member function can() on a non-object ~ APPPATH/classes/view/page/event/index.php [ 54 ]
2012-11-09 17:12:24 --- STRACE: ErrorException [ 1 ]: Call to a member function can() on a non-object ~ APPPATH/classes/view/page/event/index.php [ 54 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:46:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:46:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:46:52 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:46:52 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:47:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:47:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:47:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:47:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:47:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:47:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:47:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:47:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:47:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:47:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:47:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:47:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:48:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:48:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:48:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:48:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:49:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:49:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:49:09 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:49:09 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:49:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:49:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:49:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:49:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:49:33 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/model/event.php [ 357 ]
2012-11-09 17:49:33 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/model/event.php [ 357 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:49:34 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/model/event.php [ 357 ]
2012-11-09 17:49:34 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/model/event.php [ 357 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:49:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:49:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:49:34 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:49:34 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:49:47 --- ERROR: ErrorException [ 2 ]: date() expects at most 2 parameters, 3 given ~ APPPATH/classes/model/event.php [ 357 ]
2012-11-09 17:49:47 --- STRACE: ErrorException [ 2 ]: date() expects at most 2 parameters, 3 given ~ APPPATH/classes/model/event.php [ 357 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'date() expects ...', '/home/matt/even...', 357, Array)
#1 /home/matt/events2/application/classes/model/event.php(357): date('r', 95234406770, 'time')
#2 /home/matt/events2/application/classes/controller/event.php(21): Model_Event::filtered_list('current', Object(Model_User), false)
#3 [internal function]: Controller_Event->action_index()
#4 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#5 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#8 {main}
2012-11-09 17:49:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:49:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:49:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:49:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:50:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:50:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:50:02 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:50:02 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:50:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:50:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:50:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:50:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:50:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:50:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:50:37 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:50:37 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:50:57 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ')' ~ APPPATH/classes/model/event.php [ 352 ]
2012-11-09 17:50:57 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ')' ~ APPPATH/classes/model/event.php [ 352 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:50:58 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ')' ~ APPPATH/classes/model/event.php [ 352 ]
2012-11-09 17:50:58 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ')' ~ APPPATH/classes/model/event.php [ 352 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:50:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:50:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:50:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:50:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:51:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:51:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:51:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:51:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:52:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:52:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:52:35 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:52:35 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:53:20 --- ERROR: ErrorException [ 1 ]: Class 'ProfilerTollbar' not found ~ APPPATH/classes/model/event.php [ 359 ]
2012-11-09 17:53:20 --- STRACE: ErrorException [ 1 ]: Class 'ProfilerTollbar' not found ~ APPPATH/classes/model/event.php [ 359 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:53:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:53:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:53:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:53:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:53:29 --- ERROR: ErrorException [ 1 ]: Class 'ProfilerTolobar' not found ~ APPPATH/classes/model/event.php [ 359 ]
2012-11-09 17:53:29 --- STRACE: ErrorException [ 1 ]: Class 'ProfilerTolobar' not found ~ APPPATH/classes/model/event.php [ 359 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:53:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:53:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:53:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:53:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:53:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:53:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:53:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:53:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:53:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:53:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:53:51 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:53:51 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:54:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:54:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:54:22 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:54:22 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:54:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:54:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:54:24 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:54:24 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:54:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:54:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:54:25 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:54:25 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:54:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:54:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:54:25 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:54:25 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:54:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:54:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:54:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:54:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:54:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:54:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:54:28 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:54:28 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:54:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:54:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:54:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:54:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:54:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:54:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:54:31 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:54:31 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:54:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:54:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:54:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:54:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:55:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:55:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:55:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:55:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:55:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:55:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:55:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:55:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:55:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:55:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:55:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:55:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:55:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:55:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:55:13 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:55:13 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:55:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:55:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:55:14 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:55:14 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:55:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:55:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:55:16 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:55:16 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:55:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:55:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:55:16 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:55:16 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:58:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:58:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:58:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:58:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 17:59:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 17:59:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 17:59:19 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 17:59:19 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:04:29 --- ERROR: Exception [ 0 ]: DateTimeZone::__construct(): Unknown or bad timezone (America/New York) ~ SYSPATH/classes/kohana/date.php [ 67 ]
2012-11-09 18:04:29 --- STRACE: Exception [ 0 ]: DateTimeZone::__construct(): Unknown or bad timezone (America/New York) ~ SYSPATH/classes/kohana/date.php [ 67 ]
--
#0 /home/matt/events2/system/classes/kohana/date.php(67): DateTimeZone->__construct('America/New Yor...')
#1 /home/matt/events2/application/classes/model/event.php(366): Kohana_Date::offset('America/New Yor...', 'America/Chicago')
#2 /home/matt/events2/application/classes/controller/event.php(21): Model_Event::filtered_list('current', Object(Model_User), false)
#3 [internal function]: Controller_Event->action_index()
#4 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#5 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#8 {main}
2012-11-09 18:04:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:04:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:04:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:04:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:04:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:04:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:04:44 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:04:44 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:05:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:05:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:05:21 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:05:21 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:06:03 --- ERROR: ErrorException [ 2 ]: date() expects at most 2 parameters, 3 given ~ APPPATH/classes/model/event.php [ 367 ]
2012-11-09 18:06:03 --- STRACE: ErrorException [ 2 ]: date() expects at most 2 parameters, 3 given ~ APPPATH/classes/model/event.php [ 367 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'date() expects ...', '/home/matt/even...', 367, Array)
#1 /home/matt/events2/application/classes/model/event.php(367): date('r', 21600, 'test')
#2 /home/matt/events2/application/classes/controller/event.php(21): Model_Event::filtered_list('current', Object(Model_User), false)
#3 [internal function]: Controller_Event->action_index()
#4 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#5 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#8 {main}
2012-11-09 18:06:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:06:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:06:04 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:06:04 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:06:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:06:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:06:22 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:06:22 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:07:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:07:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:07:21 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:07:21 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:08:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:08:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:08:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:08:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:08:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:08:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:08:54 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:08:54 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:09:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:09:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:09:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:09:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:09:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:09:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:09:57 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:09:57 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:09:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:09:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:09:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:09:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:09:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:09:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:09:59 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:09:59 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:11:06 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_OBJECT_OPERATOR ~ APPPATH/classes/model/event.php [ 353 ]
2012-11-09 18:11:06 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_OBJECT_OPERATOR ~ APPPATH/classes/model/event.php [ 353 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:11:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:11:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:11:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:11:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:11:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:11:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:11:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:11:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:11:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:11:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:11:24 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:11:24 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:11:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:11:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:11:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:11:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:14:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:14:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:14:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:14:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:31:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:31:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:31:33 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:31:33 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:31:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/application_edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:31:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/application_edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:31:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:31:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:31:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cross.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:31:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cross.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:31:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:31:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:31:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/user_delete.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:31:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/user_delete.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:31:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:31:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:31:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/user_edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:31:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/user_edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:31:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:31:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:31:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:31:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:31:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:31:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:31:37 --- ERROR: Kohana_Exception [ 0 ]: The name property does not exist in the Model_User class ~ MODPATH/orm/classes/kohana/orm.php [ 621 ]
2012-11-09 18:31:37 --- STRACE: Kohana_Exception [ 0 ]: The name property does not exist in the Model_User class ~ MODPATH/orm/classes/kohana/orm.php [ 621 ]
--
#0 /home/matt/events2/application/classes/view/page/admin/event/index.php(14): Kohana_ORM->__get('name')
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Admin_Event_Index->events()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<table>???<thea...', Array)
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('<table>???<thea...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '????')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '????')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(266): Mustache->_renderTags('<!DOCTYPE html>...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!DOCTYPE html>...', Array)
#10 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#11 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#12 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#13 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#14 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Admin_Event_Index))
#15 [internal function]: Abstract_Controller_Website->after()
#16 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin_Event))
#17 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#18 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#19 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#20 {main}
2012-11-09 18:31:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:31:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:31:37 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:31:37 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:31:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:31:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:31:55 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:31:55 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:31:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:31:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:31:55 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:31:55 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:31:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:31:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:31:55 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:31:55 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:31:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:31:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:31:55 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:31:55 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:32:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:32:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:32:21 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:32:21 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:32:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:32:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:32:21 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:32:21 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:32:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:32:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:32:21 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:32:21 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:32:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:32:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:32:21 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:32:21 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:32:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:32:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:32:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:32:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:32:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:32:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:32:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:32:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:32:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:32:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:32:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:32:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:32:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:32:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:32:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:32:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:32:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:32:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:32:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:32:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:33:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:33:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:33:39 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:33:39 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:33:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:33:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:33:39 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:33:39 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:33:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:33:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:33:39 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:33:39 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:33:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:33:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:33:39 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:33:39 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:34:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:34:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:34:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:34:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:34:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:34:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:34:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:34:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:34:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:34:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:34:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:34:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:34:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:34:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:34:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:34:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:34:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:34:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:34:45 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:34:45 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:34:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:34:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:34:45 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:34:45 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:34:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:34:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:34:45 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:34:45 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:34:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:34:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:34:45 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:34:45 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:36:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:36:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:36:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:36:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:36:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:36:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:36:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:36:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:36:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:36:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:36:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:36:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:36:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:36:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:36:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:36:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:36:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:36:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:36:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:36:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:36:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:36:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:36:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:36:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:36:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:36:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:36:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:36:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:36:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:36:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:36:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:36:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:46:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:46:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:46:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:46:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:46:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:46:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:46:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:46:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:46:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:46:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:46:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:46:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:46:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:46:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:46:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:46:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:47:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:47:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:47:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:47:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:47:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:47:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:47:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:47:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:47:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:47:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:47:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:47:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:47:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:47:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:47:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:47:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:52:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:52:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:52:41 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:52:41 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:52:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:52:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:52:41 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:52:41 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:52:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:52:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:52:41 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:52:41 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 18:52:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 18:52:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 18:52:41 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 18:52:41 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:33:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:33:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:33:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:33:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:33:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:33:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:33:54 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:33:54 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:34:29 --- ERROR: ErrorException [ 1 ]: Undefined class constant 'CANCELLD' ~ APPPATH/classes/view/page/admin/event/index.php [ 20 ]
2012-11-09 19:34:29 --- STRACE: ErrorException [ 1 ]: Undefined class constant 'CANCELLD' ~ APPPATH/classes/view/page/admin/event/index.php [ 20 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:34:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:34:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:34:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:34:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:35:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:35:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:35:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:35:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:35:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:35:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:35:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:35:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:35:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:35:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:35:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:35:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:35:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:35:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:35:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:35:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:35:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:35:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:35:07 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:35:07 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:35:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:35:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:35:56 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:35:56 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:35:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:35:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:35:56 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:35:56 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:35:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:35:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:35:56 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:35:56 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:35:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:35:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:35:56 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:35:56 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:36:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:36:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:36:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:36:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:36:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:36:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:36:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:36:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:36:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:36:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:36:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:36:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:36:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:36:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:36:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:36:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:36:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:36:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:36:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:36:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:36:04 --- ERROR: ErrorException [ 2 ]: Missing argument 2 for Notices::expand(), called in /home/matt/events2/application/classes/notices.php on line 26 and defined ~ APPPATH/classes/notices.php [ 110 ]
2012-11-09 19:36:04 --- STRACE: ErrorException [ 2 ]: Missing argument 2 for Notices::expand(), called in /home/matt/events2/application/classes/notices.php on line 26 and defined ~ APPPATH/classes/notices.php [ 110 ]
--
#0 /home/matt/events2/application/classes/notices.php(110): Kohana_Core::error_handler(2, 'Missing argumen...', '/home/matt/even...', 110, Array)
#1 /home/matt/events2/application/classes/notices.php(26): Notices::expand('admin.event.rea...')
#2 /home/matt/events2/application/classes/controller/admin/event.php(33): Notices::error('admin.event.rea...')
#3 [internal function]: Controller_Admin_Event->action_reassign()
#4 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin_Event))
#5 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#8 {main}
2012-11-09 19:36:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:36:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:36:04 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:36:04 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:36:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:36:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:36:56 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:36:56 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:37:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:37:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:37:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:37:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:37:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:37:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:37:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:37:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:37:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:37:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:37:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:37:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:37:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:37:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:37:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:37:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:37:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:37:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:37:37 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:37:37 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:37:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:37:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:37:43 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:37:43 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:37:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:37:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:37:43 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:37:43 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:37:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:37:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:37:43 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:37:43 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:37:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:37:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:37:43 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:37:43 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:37:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:37:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:37:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:37:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:37:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:37:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:37:52 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:37:52 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:37:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:37:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:37:52 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:37:52 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:37:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:37:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:37:52 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:37:52 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:37:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:37:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:37:53 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:37:53 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:37:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:37:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:37:56 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:37:56 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:38:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:38:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:38:18 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:38:18 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:38:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:38:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:38:18 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:38:18 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:38:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:38:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:38:18 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:38:18 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:38:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:38:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:38:18 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:38:18 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:53:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:53:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:53:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:53:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:53:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:53:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:53:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:53:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:53:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:53:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:53:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:53:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:53:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:53:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:53:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:53:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:54:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:54:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:54:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:54:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:54:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:54:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:54:03 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:54:03 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:55:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:55:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:55:14 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:55:14 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:55:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:55:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:55:15 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:55:15 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:55:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:55:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:55:57 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:55:57 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:55:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:55:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:55:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:55:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:55:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:55:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:55:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:55:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:55:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:55:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:55:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:55:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:55:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:55:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:55:59 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:55:59 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:56:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:56:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:56:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:56:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:56:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:56:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:56:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:56:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:56:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:56:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:56:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:56:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:56:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:56:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:56:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:56:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:56:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:56:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:56:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:56:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:57:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:57:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:57:28 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:57:28 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:57:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:57:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:57:28 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:57:28 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:57:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:57:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:57:28 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:57:28 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:57:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:57:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:57:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:57:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:57:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:57:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:57:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:57:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:58:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:58:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:58:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:58:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:58:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:58:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:58:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:58:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:58:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:58:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:58:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:58:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:58:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:58:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:58:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:58:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:58:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:58:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:58:21 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:58:21 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:58:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:58:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:58:21 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:58:21 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:58:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:58:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:58:21 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:58:21 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:58:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:58:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:58:21 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:58:21 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:58:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:58:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:58:48 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:58:48 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:58:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:58:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:58:48 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:58:48 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:58:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:58:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:58:48 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:58:48 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 19:58:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 19:58:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 19:58:48 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 19:58:48 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:05:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:05:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:05:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:05:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:05:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:05:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:05:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:05:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:05:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:05:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:05:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:05:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:05:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:05:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:05:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:05:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:05:17 --- ERROR: ErrorException [ 1 ]: Call to undefined method ORM::facotry() ~ APPPATH/classes/search.php [ 7 ]
2012-11-09 21:05:17 --- STRACE: ErrorException [ 1 ]: Call to undefined method ORM::facotry() ~ APPPATH/classes/search.php [ 7 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:05:23 --- ERROR: ErrorException [ 1 ]: Call to undefined method ORM::facotry() ~ APPPATH/classes/search.php [ 7 ]
2012-11-09 21:05:23 --- STRACE: ErrorException [ 1 ]: Call to undefined method ORM::facotry() ~ APPPATH/classes/search.php [ 7 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:05:25 --- ERROR: ErrorException [ 1 ]: Call to undefined method ORM::facotry() ~ APPPATH/classes/search.php [ 7 ]
2012-11-09 21:05:25 --- STRACE: ErrorException [ 1 ]: Call to undefined method ORM::facotry() ~ APPPATH/classes/search.php [ 7 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:05:26 --- ERROR: ErrorException [ 1 ]: Call to undefined method ORM::facotry() ~ APPPATH/classes/search.php [ 7 ]
2012-11-09 21:05:26 --- STRACE: ErrorException [ 1 ]: Call to undefined method ORM::facotry() ~ APPPATH/classes/search.php [ 7 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:05:27 --- ERROR: ErrorException [ 1 ]: Call to undefined method ORM::facotry() ~ APPPATH/classes/search.php [ 7 ]
2012-11-09 21:05:27 --- STRACE: ErrorException [ 1 ]: Call to undefined method ORM::facotry() ~ APPPATH/classes/search.php [ 7 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:05:29 --- ERROR: ErrorException [ 1 ]: Call to undefined method ORM::facotry() ~ APPPATH/classes/search.php [ 7 ]
2012-11-09 21:05:29 --- STRACE: ErrorException [ 1 ]: Call to undefined method ORM::facotry() ~ APPPATH/classes/search.php [ 7 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:06:59 --- ERROR: HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/admin/event.php [ 52 ]
2012-11-09 21:06:59 --- STRACE: HTTP_Exception_404 [ 404 ]:  ~ APPPATH/classes/controller/admin/event.php [ 52 ]
--
#0 [internal function]: Controller_Admin_Event->action_character()
#1 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin_Event))
#2 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#4 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#5 {main}
2012-11-09 21:06:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:06:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:06:59 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:06:59 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:07:31 --- ERROR: ErrorException [ 1 ]: Call to undefined method ORM::facotry() ~ APPPATH/classes/search.php [ 12 ]
2012-11-09 21:07:31 --- STRACE: ErrorException [ 1 ]: Call to undefined method ORM::facotry() ~ APPPATH/classes/search.php [ 12 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:08:05 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'username' in 'where clause' [ SELECT `character`.`id` AS `id`, `character`.`name` AS `name`, `character`.`added` AS `added`, `character`.`visibility` AS `visibility`, `character`.`profession_id` AS `profession_id`, `character`.`race_id` AS `race_id`, `character`.`user_id` AS `user_id` FROM `characters` AS `character` WHERE `username` LIKE '%charac%' ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
2012-11-09 21:08:05 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'username' in 'where clause' [ SELECT `character`.`id` AS `id`, `character`.`name` AS `name`, `character`.`added` AS `added`, `character`.`visibility` AS `visibility`, `character`.`profession_id` AS `profession_id`, `character`.`race_id` AS `race_id`, `character`.`user_id` AS `user_id` FROM `characters` AS `character` WHERE `username` LIKE '%charac%' ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/matt/events2/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `charact...', 'Model_Character', Array)
#1 /home/matt/events2/modules/orm/classes/kohana/orm.php(993): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /home/matt/events2/modules/orm/classes/kohana/orm.php(934): Kohana_ORM->_load_result(true)
#3 /home/matt/events2/application/classes/search.php(12): Kohana_ORM->find_all()
#4 /home/matt/events2/application/classes/controller/admin/event.php(54): Search::character('charac')
#5 [internal function]: Controller_Admin_Event->action_character()
#6 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Admin_Event))
#7 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#10 {main}
2012-11-09 21:08:29 --- ERROR: ErrorException [ 2 ]: Attempt to assign property of non-object ~ APPPATH/classes/abstract/controller/website.php [ 80 ]
2012-11-09 21:08:29 --- STRACE: ErrorException [ 2 ]: Attempt to assign property of non-object ~ APPPATH/classes/abstract/controller/website.php [ 80 ]
--
#0 /home/matt/events2/application/classes/abstract/controller/website.php(80): Kohana_Core::error_handler(2, 'Attempt to assi...', '/home/matt/even...', 80, Array)
#1 [internal function]: Abstract_Controller_Website->after()
#2 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin_Event))
#3 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#6 {main}
2012-11-09 21:12:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:12:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:12:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:12:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:12:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:12:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:12:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:12:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:12:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:12:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:12:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:12:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:12:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:12:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:12:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:12:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:12:13 --- ERROR: ErrorException [ 1 ]: Call to undefined method View_Page_Admin_Event_Character::assets() ~ APPPATH/classes/abstract/controller/website.php [ 59 ]
2012-11-09 21:12:13 --- STRACE: ErrorException [ 1 ]: Call to undefined method View_Page_Admin_Event_Character::assets() ~ APPPATH/classes/abstract/controller/website.php [ 59 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:12:13 --- ERROR: ErrorException [ 1 ]: Call to undefined method View_Page_Admin_Event_Character::assets() ~ APPPATH/classes/abstract/controller/website.php [ 59 ]
2012-11-09 21:12:13 --- STRACE: ErrorException [ 1 ]: Call to undefined method View_Page_Admin_Event_Character::assets() ~ APPPATH/classes/abstract/controller/website.php [ 59 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:12:13 --- ERROR: ErrorException [ 1 ]: Call to undefined method View_Page_Admin_Event_Character::assets() ~ APPPATH/classes/abstract/controller/website.php [ 59 ]
2012-11-09 21:12:13 --- STRACE: ErrorException [ 1 ]: Call to undefined method View_Page_Admin_Event_Character::assets() ~ APPPATH/classes/abstract/controller/website.php [ 59 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:12:13 --- ERROR: ErrorException [ 1 ]: Call to undefined method View_Page_Admin_Event_Character::assets() ~ APPPATH/classes/abstract/controller/website.php [ 59 ]
2012-11-09 21:12:13 --- STRACE: ErrorException [ 1 ]: Call to undefined method View_Page_Admin_Event_Character::assets() ~ APPPATH/classes/abstract/controller/website.php [ 59 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:12:23 --- ERROR: ErrorException [ 1 ]: Call to undefined method View_Page_Admin_Event_Character::assets() ~ APPPATH/classes/abstract/controller/website.php [ 59 ]
2012-11-09 21:12:23 --- STRACE: ErrorException [ 1 ]: Call to undefined method View_Page_Admin_Event_Character::assets() ~ APPPATH/classes/abstract/controller/website.php [ 59 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:14:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:14:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:14:50 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:14:50 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:14:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:14:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:14:50 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:14:50 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:14:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:14:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:14:50 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:14:50 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:14:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:14:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:14:50 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:14:50 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:18:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: welcome ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:18:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: welcome ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:18:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:18:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:18:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:18:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:18:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:18:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:20:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:20:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:20:37 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:20:37 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:20:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:20:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:20:44 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:20:44 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:20:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:20:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:20:46 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:20:46 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:22:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:22:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:22:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:22:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:22:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:22:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:22:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:22:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:25:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:25:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:25:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:25:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:25:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:25:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:25:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:25:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:25:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:25:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:25:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:25:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:25:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:25:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:25:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:25:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:29:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:29:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:29:50 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:29:50 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:33:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:33:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:33:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:33:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:33:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:33:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:33:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:33:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:33:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:33:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:33:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:33:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:33:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:33:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:33:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:33:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:34:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:34:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:34:34 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:34:34 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:34:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:34:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:34:34 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:34:34 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:34:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:34:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:34:34 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:34:34 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:34:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:34:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:34:34 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:34:34 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:36:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:36:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:36:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:36:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:36:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:36:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:36:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:36:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:36:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:36:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:36:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:36:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:36:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:36:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:36:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:36:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:39:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:39:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:39:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:39:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:39:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:39:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:39:39 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:39:39 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:39:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:39:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:39:39 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:39:39 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:39:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:39:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:39:39 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:39:39 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:40:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:40:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:40:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:40:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:40:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:40:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:40:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:40:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:40:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:40:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:40:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:40:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:40:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:40:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:40:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:40:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:40:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:40:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:40:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:40:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:40:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:40:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:40:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:40:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:40:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:40:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:40:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:40:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:40:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:40:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:40:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:40:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:43:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:43:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:43:41 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:43:41 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:43:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:43:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:43:42 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:43:42 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:43:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:43:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:43:42 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:43:42 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:43:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:43:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:43:42 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:43:42 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:44:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:44:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:44:19 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:44:19 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:44:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:44:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:44:19 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:44:19 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:44:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:44:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:44:19 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:44:19 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:44:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:44:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:44:19 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:44:19 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:46:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:46:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:46:22 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:46:22 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:46:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:46:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:46:22 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:46:22 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:46:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:46:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:46:22 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:46:22 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:46:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:46:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:46:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:46:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:46:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:46:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:46:55 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:46:55 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:46:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:46:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:46:55 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:46:55 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:46:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:46:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:46:55 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:46:55 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:46:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:46:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:46:55 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:46:55 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:52:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:52:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:52:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:52:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:52:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:52:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:52:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:52:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:52:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:52:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:52:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:52:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:52:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:52:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:52:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:52:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:52:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:52:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:52:21 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:52:21 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:52:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:52:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:52:21 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:52:21 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:52:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:52:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:52:21 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:52:21 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:52:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:52:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:52:22 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:52:22 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:52:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:52:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:52:57 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:52:57 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:52:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:52:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:52:57 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:52:57 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:52:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:52:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:52:57 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:52:57 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:52:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:52:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:52:57 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:52:57 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:52:59 --- ERROR: Kohana_Exception [ 0 ]: There was no View created for this request. ~ APPPATH/classes/abstract/controller/website.php [ 77 ]
2012-11-09 21:52:59 --- STRACE: Kohana_Exception [ 0 ]: There was no View created for this request. ~ APPPATH/classes/abstract/controller/website.php [ 77 ]
--
#0 [internal function]: Abstract_Controller_Website->after()
#1 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin_Event))
#2 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#4 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#5 {main}
2012-11-09 21:53:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:53:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:53:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:53:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:53:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:53:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:53:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:53:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:53:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:53:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:53:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:53:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:53:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:53:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:53:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:53:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:55:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:55:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:55:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:55:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:55:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:55:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:55:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:55:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:55:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:55:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:55:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:55:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:55:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:55:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:55:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:55:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:56:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:56:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:56:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:56:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:56:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:56:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:56:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:56:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:56:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:56:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:56:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:56:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:56:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:56:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:56:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:56:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:56:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:56:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:56:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:56:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:56:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:56:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:56:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:56:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:56:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:56:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:56:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:56:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:56:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:56:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:56:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:56:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:56:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:56:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:56:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:56:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:57:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:57:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:57:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:57:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:57:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:57:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:57:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:57:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:57:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:57:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:57:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:57:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:57:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:57:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:57:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:57:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:58:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:58:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:58:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:58:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:58:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:58:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:58:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:58:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:58:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:58:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:58:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:58:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:58:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:58:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:58:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:58:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:58:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:58:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:58:21 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:58:21 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:58:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:58:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:58:49 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:58:49 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:58:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:58:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:58:49 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:58:49 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:58:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:58:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:58:49 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:58:49 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:58:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:58:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:58:49 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:58:49 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:59:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:59:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:59:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:59:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:59:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:59:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:59:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:59:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:59:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:59:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:59:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:59:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 21:59:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 21:59:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 21:59:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 21:59:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:00:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:00:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:00:25 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:00:25 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:00:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:00:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:00:25 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:00:25 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:00:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:00:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:00:25 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:00:25 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:00:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:00:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:00:25 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:00:25 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:01:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:01:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:01:19 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:01:19 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:01:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:01:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:01:19 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:01:19 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:01:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:01:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:01:19 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:01:19 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:01:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:01:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:01:19 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:01:19 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:01:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:01:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:01:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:01:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:01:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:01:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:01:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:01:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:01:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:01:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:01:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:01:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:01:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:01:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:01:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:01:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:03:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:03:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:03:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:03:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:03:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:03:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:03:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:03:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:03:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:03:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:03:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:03:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:03:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:03:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:03:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:03:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:03:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:03:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:03:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:03:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:03:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:03:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:03:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:03:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:03:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:03:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:03:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:03:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:03:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:03:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:03:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:03:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:07:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:07:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:07:59 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:07:59 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:07:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:07:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:07:59 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:07:59 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:07:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:07:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:07:59 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:07:59 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:07:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:07:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:07:59 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:07:59 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:08:00 --- ERROR: Kohana_Exception [ 0 ]: There was no View created for this request. ~ APPPATH/classes/abstract/controller/website.php [ 77 ]
2012-11-09 22:08:00 --- STRACE: Kohana_Exception [ 0 ]: There was no View created for this request. ~ APPPATH/classes/abstract/controller/website.php [ 77 ]
--
#0 [internal function]: Abstract_Controller_Website->after()
#1 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Admin_Event))
#2 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#4 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#5 {main}
2012-11-09 22:08:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:08:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:08:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:08:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:08:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:08:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:08:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:08:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:08:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:08:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:08:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:08:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:08:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:08:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:08:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:08:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:08:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:08:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:08:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:08:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:08:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:08:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:08:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:08:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:08:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:08:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:08:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:08:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:08:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:08:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:08:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:08:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:09:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:09:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:09:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:09:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:09:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/uncancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:09:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/uncancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:09:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:09:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:09:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:09:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:09:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:09:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:09:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:09:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:09:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:09:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:09:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:09:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:09:13 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:09:13 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:09:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:09:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:09:13 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:09:13 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:09:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:09:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:09:13 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:09:13 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:09:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:09:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:09:13 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:09:13 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:12:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:12:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:12:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:12:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:12:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:12:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:12:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:12:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:12:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:12:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:12:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:12:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:12:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:12:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:12:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:12:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:17:44 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/controller/admin/event.php [ 111 ]
2012-11-09 22:17:44 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/controller/admin/event.php [ 111 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:17:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:17:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:17:44 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:17:44 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:17:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:17:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:17:45 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:17:45 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:17:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:17:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:17:46 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:17:46 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:17:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:17:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:17:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:17:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:17:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:17:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:17:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:17:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:17:48 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/controller/admin/event.php [ 111 ]
2012-11-09 22:17:48 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/controller/admin/event.php [ 111 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:17:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:17:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:17:49 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:17:49 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:18:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:18:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:18:04 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:18:04 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:18:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:18:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:18:04 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:18:04 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:18:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:18:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:18:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:18:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:18:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:18:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:18:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:18:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:18:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:18:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:18:09 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:18:09 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:18:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:18:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:18:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:18:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:18:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:18:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:18:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:18:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:19:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:19:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:19:35 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:19:35 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:21:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:21:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:21:13 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:21:13 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:21:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:21:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:21:34 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:21:34 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:21:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:21:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:21:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:21:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:21:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:21:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:21:45 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:21:45 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:21:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:21:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:21:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:21:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:22:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:22:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:22:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:22:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:22:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:22:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:22:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:22:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:22:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:22:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:22:31 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:22:31 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:22:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:22:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:22:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:22:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:23:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:23:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:23:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:23:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:23:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:23:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:23:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:23:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:23:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:23:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:23:46 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:23:46 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:27:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/application_edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:27:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/application_edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:27:56 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:27:56 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:27:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cross.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:27:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cross.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:27:57 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:27:57 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:27:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/user_delete.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:27:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/user_delete.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:27:57 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:27:57 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:27:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/user_edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:27:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/user_edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:27:57 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:27:57 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:27:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:27:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:27:57 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:27:57 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:28:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:28:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:28:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:28:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:28:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:28:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:28:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:28:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:28:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:28:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:28:02 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:28:02 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:28:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:28:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:28:02 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:28:02 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:32:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:32:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:32:54 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:32:54 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:32:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:32:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:32:54 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:32:54 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:32:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:32:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:32:54 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:32:54 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:32:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:32:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:32:54 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:32:54 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:33:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:33:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cancel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:33:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:33:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:33:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:33:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/reassign.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:33:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:33:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:33:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:33:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:33:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:33:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:33:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:33:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:33:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:33:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:34:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/user_delete.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:34:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/user_delete.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:34:52 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:34:52 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:34:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/user_edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:34:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/user_edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:34:52 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:34:52 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:34:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:34:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:34:52 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:34:52 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:34:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:34:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:34:53 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:34:53 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:34:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:34:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:34:57 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:34:57 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:34:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:34:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:34:59 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:34:59 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:03 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:03 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:03 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:03 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:07 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:07 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:09 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:09 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:13 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:13 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cross.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/cross.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:14 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:14 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/application_edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/application_edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:14 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:14 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/user_delete.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/user_delete.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:14 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:14 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/user_edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/icons/user_edit.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:15 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:15 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:15 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:15 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:16 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:16 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:19 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:19 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:24 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:24 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:25 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:25 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:35:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-09 22:35:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-09 22:35:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-09 22:35:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-09 22:52:03 --- ERROR: ErrorException [ 2 ]: set_exception_handler() expects the argument (Kohana_Minion_Exception_Handler::handler) to be a valid callback ~ DOCROOT/index.php [ 113 ]
2012-11-09 22:52:03 --- STRACE: ErrorException [ 2 ]: set_exception_handler() expects the argument (Kohana_Minion_Exception_Handler::handler) to be a valid callback ~ DOCROOT/index.php [ 113 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'set_exception_h...', '/home/matt/even...', 113, Array)
#1 /home/matt/events2/public_html/index.php(113): set_exception_handler(Array)
#2 {main}
2012-11-09 22:52:39 --- ERROR: InvalidArgumentException [ 0 ]:  ~ MODPATH/minion/classes/minion/task.php [ 19 ]
2012-11-09 22:52:39 --- STRACE: InvalidArgumentException [ 0 ]:  ~ MODPATH/minion/classes/minion/task.php [ 19 ]
--
#0 /home/matt/events2/public_html/index.php(114): Minion_Task::factory(Array)
#1 {main}
2012-11-09 22:53:05 --- ERROR: InvalidArgumentException [ 0 ]:  ~ MODPATH/minion/classes/minion/task.php [ 19 ]
2012-11-09 22:53:05 --- STRACE: InvalidArgumentException [ 0 ]:  ~ MODPATH/minion/classes/minion/task.php [ 19 ]
--
#0 /home/matt/events2/public_html/index.php(114): Minion_Task::factory(Array)
#1 {main}
2012-11-09 22:54:01 --- ERROR: InvalidArgumentException [ 0 ]:  ~ MODPATH/minion/classes/minion/task.php [ 19 ]
2012-11-09 22:54:01 --- STRACE: InvalidArgumentException [ 0 ]:  ~ MODPATH/minion/classes/minion/task.php [ 19 ]
--
#0 /home/matt/events2/public_html/index.php(114): Minion_Task::factory(Array)
#1 {main}
2012-11-09 22:54:19 --- ERROR: InvalidArgumentException [ 0 ]:  ~ MODPATH/minion/classes/minion/task.php [ 19 ]
2012-11-09 22:54:19 --- STRACE: InvalidArgumentException [ 0 ]:  ~ MODPATH/minion/classes/minion/task.php [ 19 ]
--
#0 /home/matt/events2/public_html/index.php(114): Minion_Task::factory(Array)
#1 {main}
2012-11-09 22:54:42 --- ERROR: InvalidArgumentException [ 0 ]:  ~ MODPATH/minion/classes/minion/task.php [ 19 ]
2012-11-09 22:54:42 --- STRACE: InvalidArgumentException [ 0 ]:  ~ MODPATH/minion/classes/minion/task.php [ 19 ]
--
#0 /home/matt/events2/public_html/index.php(114): Minion_Task::factory(Array)
#1 {main}
2012-11-09 22:58:09 --- ERROR: ErrorException [ 1 ]: Wrong parameters for Exception([string $exception [, long $code [, Exception $previous = NULL]]]) ~ MODPATH/minion/classes/minion/task.php [ 19 ]
2012-11-09 22:58:09 --- STRACE: ErrorException [ 1 ]: Wrong parameters for Exception([string $exception [, long $code [, Exception $previous = NULL]]]) ~ MODPATH/minion/classes/minion/task.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}