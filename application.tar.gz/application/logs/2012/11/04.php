<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2012-11-04 10:33:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 10:33:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 10:33:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 10:33:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 10:33:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 10:33:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 10:33:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 10:33:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 10:33:30 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_CONSTANT_ENCAPSED_STRING, expecting ')' ~ APPPATH/classes/model/location.php [ 28 ]
2012-11-04 10:33:30 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_CONSTANT_ENCAPSED_STRING, expecting ')' ~ APPPATH/classes/model/location.php [ 28 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 10:33:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 10:33:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 10:33:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 10:33:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 10:33:56 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/view/page/event/add.php [ 16 ]
2012-11-04 10:33:56 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/view/page/event/add.php [ 16 ]
--
#0 /home/matt/events2/application/classes/view/page/event/add.php(16): Kohana_Core::error_handler(8, 'Trying to get p...', '/home/matt/even...', 16, Array)
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Add->location_list()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('location_list', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('location_list')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#location_...')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('?<form action="...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '????')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '????')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(266): Mustache->_renderTags('<!DOCTYPE html>...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!DOCTYPE html>...', Array)
#13 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#14 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#15 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#16 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#17 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Add))
#18 [internal function]: Abstract_Controller_Website->after()
#19 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#20 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#21 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#22 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#23 {main}
2012-11-04 10:33:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 10:33:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 10:33:56 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 10:33:56 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 10:35:55 --- ERROR: ErrorException [ 8 ]: Undefined property: View_Page_Event_Add::$event_data ~ APPPATH/classes/view/page/event/add.php [ 16 ]
2012-11-04 10:35:55 --- STRACE: ErrorException [ 8 ]: Undefined property: View_Page_Event_Add::$event_data ~ APPPATH/classes/view/page/event/add.php [ 16 ]
--
#0 /home/matt/events2/application/classes/view/page/event/add.php(16): Kohana_Core::error_handler(8, 'Undefined prope...', '/home/matt/even...', 16, Array)
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Add->location_list()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('location_list', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('location_list')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('>??{{#location_...')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</li>????...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('/>???????{{#err...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('?<form action="...', Array)
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('?<form action="...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '????')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '????')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(266): Mustache->_renderTags('<!DOCTYPE html>...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!DOCTYPE html>...', Array)
#13 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#14 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#15 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#16 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#17 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Add))
#18 [internal function]: Abstract_Controller_Website->after()
#19 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#20 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#21 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#22 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#23 {main}
2012-11-04 10:35:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 10:35:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 10:35:55 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 10:35:55 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 10:37:22 --- ERROR: ErrorException [ 1 ]: Class 'Model_Characer' not found ~ APPPATH/classes/view/page/event/add.php [ 33 ]
2012-11-04 10:37:22 --- STRACE: ErrorException [ 1 ]: Class 'Model_Characer' not found ~ APPPATH/classes/view/page/event/add.php [ 33 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 10:37:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 10:37:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 10:37:22 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 10:37:22 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 10:37:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 10:37:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 10:37:33 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 10:37:33 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 10:40:46 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Model_Location::to_id() must be an instance of string, string given, called in /home/matt/events2/application/classes/model/event.php on line 69 and defined ~ APPPATH/classes/model/location.php [ 52 ]
2012-11-04 10:40:46 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Model_Location::to_id() must be an instance of string, string given, called in /home/matt/events2/application/classes/model/event.php on line 69 and defined ~ APPPATH/classes/model/location.php [ 52 ]
--
#0 /home/matt/events2/application/classes/model/location.php(52): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/home/matt/even...', 52, Array)
#1 /home/matt/events2/application/classes/model/event.php(69): Model_Location::to_id('Ascalonian Cata...')
#2 /home/matt/events2/application/classes/controller/event.php(65): Model_Event->create_event(Object(Model_User), Array)
#3 [internal function]: Controller_Event->action_add()
#4 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#5 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#8 {main}
2012-11-04 10:40:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 10:40:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 10:40:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 10:40:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 10:45:07 --- ERROR: ErrorException [ 2 ]: Missing argument 3 for Kohana_Valid::range() ~ SYSPATH/classes/kohana/valid.php [ 478 ]
2012-11-04 10:45:07 --- STRACE: ErrorException [ 2 ]: Missing argument 3 for Kohana_Valid::range() ~ SYSPATH/classes/kohana/valid.php [ 478 ]
--
#0 /home/matt/events2/system/classes/kohana/valid.php(478): Kohana_Core::error_handler(2, 'Missing argumen...', '/home/matt/even...', 478, Array)
#1 [internal function]: Kohana_Valid::range(NULL, Array)
#2 /home/matt/events2/system/classes/kohana/validation.php(391): ReflectionMethod->invokeArgs(NULL, Array)
#3 /home/matt/events2/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /home/matt/events2/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /home/matt/events2/application/classes/model/event.php(99): Kohana_ORM->create()
#6 /home/matt/events2/application/classes/controller/event.php(65): Model_Event->create_event(Object(Model_User), Array)
#7 [internal function]: Controller_Event->action_add()
#8 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#9 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#11 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#12 {main}
2012-11-04 10:45:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 10:45:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 10:45:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 10:45:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 10:53:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 10:53:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 10:53:14 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 10:53:14 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 10:53:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 10:53:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 10:53:15 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 10:53:15 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 10:53:40 --- ERROR: ErrorException [ 2 ]: Missing argument 3 for Kohana_Valid::range() ~ SYSPATH/classes/kohana/valid.php [ 478 ]
2012-11-04 10:53:40 --- STRACE: ErrorException [ 2 ]: Missing argument 3 for Kohana_Valid::range() ~ SYSPATH/classes/kohana/valid.php [ 478 ]
--
#0 /home/matt/events2/system/classes/kohana/valid.php(478): Kohana_Core::error_handler(2, 'Missing argumen...', '/home/matt/even...', 478, Array)
#1 [internal function]: Kohana_Valid::range(NULL, Array)
#2 /home/matt/events2/system/classes/kohana/validation.php(391): ReflectionMethod->invokeArgs(NULL, Array)
#3 /home/matt/events2/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /home/matt/events2/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /home/matt/events2/application/classes/model/event.php(99): Kohana_ORM->create()
#6 /home/matt/events2/application/classes/controller/event.php(65): Model_Event->create_event(Object(Model_User), Array)
#7 [internal function]: Controller_Event->action_add()
#8 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#9 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#11 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#12 {main}
2012-11-04 10:53:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 10:53:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 10:53:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 10:53:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 10:54:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 10:54:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 10:54:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 10:54:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 10:54:29 --- ERROR: ErrorException [ 2 ]: Missing argument 3 for Kohana_Valid::range() ~ SYSPATH/classes/kohana/valid.php [ 478 ]
2012-11-04 10:54:29 --- STRACE: ErrorException [ 2 ]: Missing argument 3 for Kohana_Valid::range() ~ SYSPATH/classes/kohana/valid.php [ 478 ]
--
#0 /home/matt/events2/system/classes/kohana/valid.php(478): Kohana_Core::error_handler(2, 'Missing argumen...', '/home/matt/even...', 478, Array)
#1 [internal function]: Kohana_Valid::range('5', Array)
#2 /home/matt/events2/system/classes/kohana/validation.php(391): ReflectionMethod->invokeArgs(NULL, Array)
#3 /home/matt/events2/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /home/matt/events2/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /home/matt/events2/application/classes/model/event.php(100): Kohana_ORM->create()
#6 /home/matt/events2/application/classes/controller/event.php(65): Model_Event->create_event(Object(Model_User), Array)
#7 [internal function]: Controller_Event->action_add()
#8 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#9 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#11 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#12 {main}
2012-11-04 10:54:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 10:54:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 10:54:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 10:54:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 10:55:31 --- ERROR: ErrorException [ 2 ]: Missing argument 3 for Kohana_Valid::range() ~ SYSPATH/classes/kohana/valid.php [ 478 ]
2012-11-04 10:55:31 --- STRACE: ErrorException [ 2 ]: Missing argument 3 for Kohana_Valid::range() ~ SYSPATH/classes/kohana/valid.php [ 478 ]
--
#0 /home/matt/events2/system/classes/kohana/valid.php(478): Kohana_Core::error_handler(2, 'Missing argumen...', '/home/matt/even...', 478, Array)
#1 [internal function]: Kohana_Valid::range('5', 1)
#2 /home/matt/events2/system/classes/kohana/validation.php(391): ReflectionMethod->invokeArgs(NULL, Array)
#3 /home/matt/events2/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /home/matt/events2/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /home/matt/events2/application/classes/model/event.php(100): Kohana_ORM->create()
#6 /home/matt/events2/application/classes/controller/event.php(65): Model_Event->create_event(Object(Model_User), Array)
#7 [internal function]: Controller_Event->action_add()
#8 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#9 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#11 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#12 {main}
2012-11-04 10:55:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 10:55:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 10:55:31 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 10:55:31 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 10:57:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 10:57:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 10:57:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 10:57:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 10:58:14 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ';', expecting ')' ~ APPPATH/classes/model/event.php [ 43 ]
2012-11-04 10:58:14 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ';', expecting ')' ~ APPPATH/classes/model/event.php [ 43 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 10:58:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 10:58:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 10:58:14 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 10:58:14 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 10:58:29 --- ERROR: ErrorException [ 2 ]: Missing argument 3 for Kohana_Valid::range() ~ SYSPATH/classes/kohana/valid.php [ 478 ]
2012-11-04 10:58:29 --- STRACE: ErrorException [ 2 ]: Missing argument 3 for Kohana_Valid::range() ~ SYSPATH/classes/kohana/valid.php [ 478 ]
--
#0 /home/matt/events2/system/classes/kohana/valid.php(478): Kohana_Core::error_handler(2, 'Missing argumen...', '/home/matt/even...', 478, Array)
#1 [internal function]: Kohana_Valid::range('5', 1)
#2 /home/matt/events2/system/classes/kohana/validation.php(391): ReflectionMethod->invokeArgs(NULL, Array)
#3 /home/matt/events2/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /home/matt/events2/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /home/matt/events2/application/classes/model/event.php(100): Kohana_ORM->create()
#6 /home/matt/events2/application/classes/controller/event.php(65): Model_Event->create_event(Object(Model_User), Array)
#7 [internal function]: Controller_Event->action_add()
#8 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#9 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#11 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#12 {main}
2012-11-04 10:58:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 10:58:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 10:58:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 10:58:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 11:39:50 --- ERROR: ErrorException [ 2 ]: Missing argument 3 for Kohana_Valid::range() ~ SYSPATH/classes/kohana/valid.php [ 478 ]
2012-11-04 11:39:50 --- STRACE: ErrorException [ 2 ]: Missing argument 3 for Kohana_Valid::range() ~ SYSPATH/classes/kohana/valid.php [ 478 ]
--
#0 /home/matt/events2/system/classes/kohana/valid.php(478): Kohana_Core::error_handler(2, 'Missing argumen...', '/home/matt/even...', 478, Array)
#1 [internal function]: Kohana_Valid::range('5', 1)
#2 /home/matt/events2/system/classes/kohana/validation.php(391): ReflectionMethod->invokeArgs(NULL, Array)
#3 /home/matt/events2/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /home/matt/events2/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /home/matt/events2/application/classes/model/event.php(100): Kohana_ORM->create()
#6 /home/matt/events2/application/classes/controller/event.php(65): Model_Event->create_event(Object(Model_User), Array)
#7 [internal function]: Controller_Event->action_add()
#8 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#9 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#11 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#12 {main}
2012-11-04 11:39:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 11:39:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 11:39:51 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 11:39:51 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 11:40:12 --- ERROR: ErrorException [ 2 ]: Missing argument 3 for Kohana_Valid::range() ~ SYSPATH/classes/kohana/valid.php [ 478 ]
2012-11-04 11:40:12 --- STRACE: ErrorException [ 2 ]: Missing argument 3 for Kohana_Valid::range() ~ SYSPATH/classes/kohana/valid.php [ 478 ]
--
#0 /home/matt/events2/system/classes/kohana/valid.php(478): Kohana_Core::error_handler(2, 'Missing argumen...', '/home/matt/even...', 478, Array)
#1 [internal function]: Kohana_Valid::range('5', Array)
#2 /home/matt/events2/system/classes/kohana/validation.php(391): ReflectionMethod->invokeArgs(NULL, Array)
#3 /home/matt/events2/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /home/matt/events2/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /home/matt/events2/application/classes/model/event.php(100): Kohana_ORM->create()
#6 /home/matt/events2/application/classes/controller/event.php(65): Model_Event->create_event(Object(Model_User), Array)
#7 [internal function]: Controller_Event->action_add()
#8 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#9 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#11 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#12 {main}
2012-11-04 11:40:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 11:40:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 11:40:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 11:40:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 11:40:34 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ';', expecting ')' ~ APPPATH/classes/model/event.php [ 43 ]
2012-11-04 11:40:34 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ';', expecting ')' ~ APPPATH/classes/model/event.php [ 43 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 11:40:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 11:40:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 11:40:34 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 11:40:34 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 11:40:49 --- ERROR: ErrorException [ 2 ]: Missing argument 3 for Kohana_Valid::range() ~ SYSPATH/classes/kohana/valid.php [ 478 ]
2012-11-04 11:40:49 --- STRACE: ErrorException [ 2 ]: Missing argument 3 for Kohana_Valid::range() ~ SYSPATH/classes/kohana/valid.php [ 478 ]
--
#0 /home/matt/events2/system/classes/kohana/valid.php(478): Kohana_Core::error_handler(2, 'Missing argumen...', '/home/matt/even...', 478, Array)
#1 [internal function]: Kohana_Valid::range('5', Array)
#2 /home/matt/events2/system/classes/kohana/validation.php(391): ReflectionMethod->invokeArgs(NULL, Array)
#3 /home/matt/events2/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /home/matt/events2/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /home/matt/events2/application/classes/model/event.php(100): Kohana_ORM->create()
#6 /home/matt/events2/application/classes/controller/event.php(65): Model_Event->create_event(Object(Model_User), Array)
#7 [internal function]: Controller_Event->action_add()
#8 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#9 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#11 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#12 {main}
2012-11-04 11:40:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 11:40:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 11:40:49 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 11:40:49 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 11:41:49 --- ERROR: ErrorException [ 2 ]: Missing argument 3 for Kohana_Valid::range() ~ SYSPATH/classes/kohana/valid.php [ 478 ]
2012-11-04 11:41:49 --- STRACE: ErrorException [ 2 ]: Missing argument 3 for Kohana_Valid::range() ~ SYSPATH/classes/kohana/valid.php [ 478 ]
--
#0 /home/matt/events2/system/classes/kohana/valid.php(478): Kohana_Core::error_handler(2, 'Missing argumen...', '/home/matt/even...', 478, Array)
#1 [internal function]: Kohana_Valid::range(Array, Array)
#2 /home/matt/events2/system/classes/kohana/validation.php(391): ReflectionMethod->invokeArgs(NULL, Array)
#3 /home/matt/events2/modules/orm/classes/kohana/orm.php(1202): Kohana_Validation->check()
#4 /home/matt/events2/modules/orm/classes/kohana/orm.php(1230): Kohana_ORM->check(NULL)
#5 /home/matt/events2/application/classes/model/event.php(100): Kohana_ORM->create()
#6 /home/matt/events2/application/classes/controller/event.php(65): Model_Event->create_event(Object(Model_User), Array)
#7 [internal function]: Controller_Event->action_add()
#8 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#9 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#11 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#12 {main}
2012-11-04 11:41:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 11:41:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 11:41:50 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 11:41:50 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:20:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:20:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:20:09 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:20:09 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:21:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:21:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:23:04 --- ERROR: ErrorException [ 8 ]: Undefined variable: event ~ APPPATH/classes/controller/event.php [ 80 ]
2012-11-04 13:23:04 --- STRACE: ErrorException [ 8 ]: Undefined variable: event ~ APPPATH/classes/controller/event.php [ 80 ]
--
#0 /home/matt/events2/application/classes/controller/event.php(80): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/matt/even...', 80, Array)
#1 [internal function]: Controller_Event->action_add()
#2 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#3 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#6 {main}
2012-11-04 13:23:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:23:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:23:04 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:23:04 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:23:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:23:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:23:37 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:23:37 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:24:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:24:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:24:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:24:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:26:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:26:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:26:22 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:26:22 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:26:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:26:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:26:28 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:26:28 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:29:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:29:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:29:39 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:29:39 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:30:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:30:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:30:55 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:30:55 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:31:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:31:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:31:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:31:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:31:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:31:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:31:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:31:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:31:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:31:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:31:13 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:31:13 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:31:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:31:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:31:13 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:31:13 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:31:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:31:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:31:14 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:31:14 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:31:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:31:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:31:15 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:31:15 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:32:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:32:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:32:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:32:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:32:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:32:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:32:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:32:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:32:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:32:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:32:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:32:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:33:29 --- ERROR: ErrorException [ 1 ]: Call to undefined method ORM_Validation_Exception::message() ~ APPPATH/classes/controller/event.php [ 79 ]
2012-11-04 13:33:29 --- STRACE: ErrorException [ 1 ]: Call to undefined method ORM_Validation_Exception::message() ~ APPPATH/classes/controller/event.php [ 79 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:33:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:33:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:33:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:33:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:33:44 --- ERROR: ErrorException [ 1 ]: Cannot access protected property ORM_Validation_Exception::$message ~ APPPATH/classes/controller/event.php [ 79 ]
2012-11-04 13:33:44 --- STRACE: ErrorException [ 1 ]: Cannot access protected property ORM_Validation_Exception::$message ~ APPPATH/classes/controller/event.php [ 79 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:33:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:33:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:33:44 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:33:44 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:33:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:33:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:33:57 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:33:57 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:35:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:35:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:35:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:35:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:36:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:36:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:36:50 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:36:50 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:37:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:37:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:37:44 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:37:44 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:39:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:39:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:39:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:39:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:40:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:40:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:40:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:40:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:41:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:41:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:41:07 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:41:07 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:41:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:41:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:41:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:41:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:42:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:42:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:42:22 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:42:22 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:46:03 --- ERROR: Database_Exception [ 1146 ]: Table 'gw2.enrollments' doesn't exist [ SHOW FULL COLUMNS FROM `enrollments` ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
2012-11-04 13:46:03 --- STRACE: Database_Exception [ 1146 ]: Table 'gw2.enrollments' doesn't exist [ SHOW FULL COLUMNS FROM `enrollments` ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/matt/events2/modules/profilertoolbar/classes/kohana/database/mysql.php(392): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#1 /home/matt/events2/modules/orm/classes/kohana/orm.php(1538): Kohana_Database_MySQL->list_columns('enrollments')
#2 /home/matt/events2/modules/orm/classes/kohana/orm.php(392): Kohana_ORM->list_columns()
#3 /home/matt/events2/modules/orm/classes/kohana/orm.php(337): Kohana_ORM->reload_columns()
#4 /home/matt/events2/modules/orm/classes/kohana/orm.php(246): Kohana_ORM->_initialize()
#5 /home/matt/events2/modules/orm/classes/kohana/orm.php(37): Kohana_ORM->__construct(Array)
#6 /home/matt/events2/application/classes/model/event.php(189): Kohana_ORM::factory('enrollment', Array)
#7 /home/matt/events2/application/classes/controller/event.php(70): Model_Event->enroll(Object(Model_User), 'Character One', 1, 'Event leader')
#8 [internal function]: Controller_Event->action_add()
#9 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#10 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#13 {main}
2012-11-04 13:46:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:46:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:46:03 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 13:46:03 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:47:42 --- ERROR: ErrorException [ 1 ]: Class 'ProfilerToolbar' not found ~ APPPATH/classes/model/event.php [ 63 ]
2012-11-04 13:47:42 --- STRACE: ErrorException [ 1 ]: Class 'ProfilerToolbar' not found ~ APPPATH/classes/model/event.php [ 63 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 13:47:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:47:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:48:09 --- ERROR: Database_Exception [ 1146 ]: Table 'gw2.enrollments' doesn't exist [ SHOW FULL COLUMNS FROM `enrollments` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-11-04 13:48:09 --- STRACE: Database_Exception [ 1146 ]: Table 'gw2.enrollments' doesn't exist [ SHOW FULL COLUMNS FROM `enrollments` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/matt/events2/modules/database/classes/kohana/database/mysql.php(358): Kohana_Database_MySQL->query(1, 'SHOW FULL COLUM...', false)
#1 /home/matt/events2/modules/orm/classes/kohana/orm.php(1538): Kohana_Database_MySQL->list_columns('enrollments')
#2 /home/matt/events2/modules/orm/classes/kohana/orm.php(392): Kohana_ORM->list_columns()
#3 /home/matt/events2/modules/orm/classes/kohana/orm.php(337): Kohana_ORM->reload_columns()
#4 /home/matt/events2/modules/orm/classes/kohana/orm.php(246): Kohana_ORM->_initialize()
#5 /home/matt/events2/modules/orm/classes/kohana/orm.php(37): Kohana_ORM->__construct(Array)
#6 /home/matt/events2/application/classes/model/event.php(183): Kohana_ORM::factory('enrollment', Array)
#7 /home/matt/events2/application/classes/controller/event.php(70): Model_Event->enroll(Object(Model_User), 'Character One', 1, 'Event leader')
#8 [internal function]: Controller_Event->action_add()
#9 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#10 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#13 {main}
2012-11-04 13:48:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:48:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:49:05 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Model_Enrollment::details() must be an instance of int, integer given, called in /home/matt/events2/application/classes/model/event.php on line 190 and defined ~ APPPATH/classes/model/enrollment.php [ 50 ]
2012-11-04 13:49:05 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Model_Enrollment::details() must be an instance of int, integer given, called in /home/matt/events2/application/classes/model/event.php on line 190 and defined ~ APPPATH/classes/model/enrollment.php [ 50 ]
--
#0 /home/matt/events2/application/classes/model/enrollment.php(50): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/home/matt/even...', 50, Array)
#1 /home/matt/events2/application/classes/model/event.php(190): Model_Enrollment->details(1, 'Event leader')
#2 /home/matt/events2/application/classes/controller/event.php(70): Model_Event->enroll(Object(Model_User), 'Character One', 1, 'Event leader')
#3 [internal function]: Controller_Event->action_add()
#4 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#5 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#8 {main}
2012-11-04 13:49:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 13:49:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 13:51:01 --- ERROR: Kohana_Exception [ 0 ]: The this property does not exist in the Model_Event class ~ MODPATH/orm/classes/kohana/orm.php [ 621 ]
2012-11-04 13:51:01 --- STRACE: Kohana_Exception [ 0 ]: The this property does not exist in the Model_Event class ~ MODPATH/orm/classes/kohana/orm.php [ 621 ]
--
#0 /home/matt/events2/application/classes/view/page/event/index.php(31): Kohana_ORM->__get('this')
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</select>...')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????{{#filte...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????<select n...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<section id=...', Array)
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<section id=...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '????')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '????')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(266): Mustache->_renderTags('<!DOCTYPE html>...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!DOCTYPE html>...', Array)
#13 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#14 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#15 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#16 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#17 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Index))
#18 [internal function]: Abstract_Controller_Website->after()
#19 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#20 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#21 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#22 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#23 {main}
2012-11-04 13:52:09 --- ERROR: ErrorException [ 2 ]: Missing argument 2 for Date::to_local_time(), called in /home/matt/events2/application/classes/view/page/event/index.php on line 31 and defined ~ APPPATH/classes/date.php [ 114 ]
2012-11-04 13:52:09 --- STRACE: ErrorException [ 2 ]: Missing argument 2 for Date::to_local_time(), called in /home/matt/events2/application/classes/view/page/event/index.php on line 31 and defined ~ APPPATH/classes/date.php [ 114 ]
--
#0 /home/matt/events2/application/classes/date.php(114): Kohana_Core::error_handler(2, 'Missing argumen...', '/home/matt/even...', 114, Array)
#1 /home/matt/events2/application/classes/view/page/event/index.php(31): Date::to_local_time('America/Chicago')
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</select>...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????{{#filte...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????<select n...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<section id=...', Array)
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<section id=...')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '????')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '????')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(266): Mustache->_renderTags('<!DOCTYPE html>...')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!DOCTYPE html>...', Array)
#14 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#15 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#16 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#17 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#18 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Index))
#19 [internal function]: Abstract_Controller_Website->after()
#20 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#21 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#22 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#23 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#24 {main}
2012-11-04 13:53:32 --- ERROR: ErrorException [ 8 ]: A non well formed numeric value encountered ~ APPPATH/classes/view/page/event/index.php [ 31 ]
2012-11-04 13:53:32 --- STRACE: ErrorException [ 8 ]: A non well formed numeric value encountered ~ APPPATH/classes/view/page/event/index.php [ 31 ]
--
#0 [internal function]: Kohana_Core::error_handler(8, 'A non well form...', '/home/matt/even...', 31, Array)
#1 /home/matt/events2/application/classes/view/page/event/index.php(31): date('g:i A ', '-21600CST')
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</select>...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????{{#filte...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????<select n...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<section id=...', Array)
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<section id=...')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '????')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '????')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(266): Mustache->_renderTags('<!DOCTYPE html>...')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!DOCTYPE html>...', Array)
#14 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#15 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#16 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#17 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#18 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Index))
#19 [internal function]: Abstract_Controller_Website->after()
#20 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#21 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#22 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#23 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#24 {main}
2012-11-04 13:54:51 --- ERROR: Kohana_Exception [ 0 ]: The this property does not exist in the Model_Event class ~ MODPATH/orm/classes/kohana/orm.php [ 621 ]
2012-11-04 13:54:51 --- STRACE: Kohana_Exception [ 0 ]: The this property does not exist in the Model_Event class ~ MODPATH/orm/classes/kohana/orm.php [ 621 ]
--
#0 /home/matt/events2/application/classes/view/page/event/index.php(32): Kohana_ORM->__get('this')
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->events()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('events', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('events')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</select>...')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????{{#filte...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????<select n...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<section id=...', Array)
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<section id=...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '????')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '????')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(266): Mustache->_renderTags('<!DOCTYPE html>...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!DOCTYPE html>...', Array)
#13 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#14 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#15 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#16 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#17 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Index))
#18 [internal function]: Abstract_Controller_Website->after()
#19 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#20 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#21 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#22 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#23 {main}
2012-11-04 13:55:24 --- ERROR: ErrorException [ 1 ]: Class 'ProfilerToolbar' not found ~ APPPATH/classes/abstract/view/page.php [ 168 ]
2012-11-04 13:55:24 --- STRACE: ErrorException [ 1 ]: Class 'ProfilerToolbar' not found ~ APPPATH/classes/abstract/view/page.php [ 168 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 15:09:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:09:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:09:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 15:09:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 15:09:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:09:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:09:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 15:09:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 15:09:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:09:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:09:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 15:09:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 15:09:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:09:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:09:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 15:09:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 15:09:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:09:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:09:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 15:09:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 15:10:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:10:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:10:19 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 15:10:19 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 15:10:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:10:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:10:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 15:10:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 15:11:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:11:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:11:02 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 15:11:02 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 15:11:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:11:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:11:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 15:11:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 15:12:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:12:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:12:34 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 15:12:34 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 15:13:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:13:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:13:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 15:13:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 15:13:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:13:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:13:07 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 15:13:07 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 15:15:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:15:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:15:41 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 15:15:41 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 15:15:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:15:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:15:43 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 15:15:43 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 15:36:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:36:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:36:41 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 15:36:41 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 15:51:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:51:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:51:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 15:51:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 15:51:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: event/display/3/dicking-around-in-wvw ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:51:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: event/display/3/dicking-around-in-wvw ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:51:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: event/display/3/dicking-around-in-wvw ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:51:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: event/display/3/dicking-around-in-wvw ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:51:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: event/display/3/dicking-around-in-wvw ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:51:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: event/display/3/dicking-around-in-wvw ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:51:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: event/display/3/dicking-around-in-wvw ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:51:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: event/display/3/dicking-around-in-wvw ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:51:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: event/display/3/dicking-around-in-wvw ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:51:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: event/display/3/dicking-around-in-wvw ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:51:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: event/display/3 ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:51:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: event/display/3 ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:51:53 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 15:51:53 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 15:51:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:51:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:51:53 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 15:51:53 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 15:52:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 15:52:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 15:52:18 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 15:52:18 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:16:25 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '}' ~ APPPATH/classes/view/page/event/display.php [ 162 ]
2012-11-04 16:16:25 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '}' ~ APPPATH/classes/view/page/event/display.php [ 162 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:16:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:16:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:16:25 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:16:25 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:16:39 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Enrollment::is_signed_up() ~ APPPATH/classes/policy/event/enroll.php [ 31 ]
2012-11-04 16:16:39 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Enrollment::is_signed_up() ~ APPPATH/classes/policy/event/enroll.php [ 31 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:16:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:16:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:16:39 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:16:39 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:19:05 --- ERROR: ErrorException [ 2 ]: Missing argument 2 for Model_Enrollment::is_enrolled(), called in /home/matt/events2/application/classes/policy/event/enroll.php on line 31 and defined ~ APPPATH/classes/model/enrollment.php [ 82 ]
2012-11-04 16:19:05 --- STRACE: ErrorException [ 2 ]: Missing argument 2 for Model_Enrollment::is_enrolled(), called in /home/matt/events2/application/classes/policy/event/enroll.php on line 31 and defined ~ APPPATH/classes/model/enrollment.php [ 82 ]
--
#0 /home/matt/events2/application/classes/model/enrollment.php(82): Kohana_Core::error_handler(2, 'Missing argumen...', '/home/matt/even...', 82, Array)
#1 /home/matt/events2/application/classes/policy/event/enroll.php(31): Model_Enrollment::is_enrolled(Object(Model_Event))
#2 /home/matt/events2/application/classes/model/user.php(69): Policy_Event_Enroll->execute(Object(Model_User), Array)
#3 /home/matt/events2/application/classes/view/page/event/display.php(151): Model_User->can('event_enroll', Array)
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Display->enroll()
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('enroll', Array)
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('enroll')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('?????????????</...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??{{^attendees....')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???????<div id=...', Array)
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???????<div id=...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '????')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '????')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(266): Mustache->_renderTags('<!DOCTYPE html>...')
#14 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!DOCTYPE html>...', Array)
#15 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#16 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#17 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#18 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#19 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Display))
#20 [internal function]: Abstract_Controller_Website->after()
#21 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#22 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#23 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#24 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#25 {main}
2012-11-04 16:19:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:19:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:19:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:19:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:19:45 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ')', expecting ']' ~ APPPATH/classes/policy/event/enroll.php [ 31 ]
2012-11-04 16:19:45 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ')', expecting ']' ~ APPPATH/classes/policy/event/enroll.php [ 31 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:19:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:19:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:19:45 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:19:45 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:19:58 --- ERROR: ErrorException [ 1 ]: Call to a member function has() on a non-object ~ APPPATH/classes/model/enrollment.php [ 87 ]
2012-11-04 16:19:58 --- STRACE: ErrorException [ 1 ]: Call to a member function has() on a non-object ~ APPPATH/classes/model/enrollment.php [ 87 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:19:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:19:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:19:59 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:19:59 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:22:58 --- ERROR: ErrorException [ 1 ]: Call to a member function has() on a non-object ~ APPPATH/classes/model/enrollment.php [ 87 ]
2012-11-04 16:22:58 --- STRACE: ErrorException [ 1 ]: Call to a member function has() on a non-object ~ APPPATH/classes/model/enrollment.php [ 87 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:22:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:22:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:22:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:22:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:23:13 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Model_Enrollment::is_enrolled() must implement interface Model_ACL_User, instance of Model_Event given, called in /home/matt/events2/application/classes/policy/event/enroll.php on line 31 and defined ~ APPPATH/classes/model/enrollment.php [ 82 ]
2012-11-04 16:23:13 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Model_Enrollment::is_enrolled() must implement interface Model_ACL_User, instance of Model_Event given, called in /home/matt/events2/application/classes/policy/event/enroll.php on line 31 and defined ~ APPPATH/classes/model/enrollment.php [ 82 ]
--
#0 /home/matt/events2/application/classes/model/enrollment.php(82): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/home/matt/even...', 82, Array)
#1 /home/matt/events2/application/classes/policy/event/enroll.php(31): Model_Enrollment::is_enrolled(Object(Model_Event), Array)
#2 /home/matt/events2/application/classes/model/user.php(69): Policy_Event_Enroll->execute(Object(Model_User), Array)
#3 /home/matt/events2/application/classes/view/page/event/display.php(151): Model_User->can('event_enroll', Array)
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Display->enroll()
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('enroll', Array)
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('enroll')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('?????????????</...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??{{^attendees....')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???????<div id=...', Array)
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???????<div id=...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '????')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '????')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(266): Mustache->_renderTags('<!DOCTYPE html>...')
#14 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!DOCTYPE html>...', Array)
#15 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#16 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#17 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#18 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#19 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Display))
#20 [internal function]: Abstract_Controller_Website->after()
#21 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#22 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#23 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#24 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#25 {main}
2012-11-04 16:23:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:23:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:23:13 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:23:13 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:23:34 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ':' ~ APPPATH/classes/policy/event/withdraw.php [ 21 ]
2012-11-04 16:23:34 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ':' ~ APPPATH/classes/policy/event/withdraw.php [ 21 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:23:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:23:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:23:34 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:23:34 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:23:51 --- ERROR: ErrorException [ 8 ]: Undefined index: characters ~ APPPATH/classes/policy/event/withdraw.php [ 16 ]
2012-11-04 16:23:51 --- STRACE: ErrorException [ 8 ]: Undefined index: characters ~ APPPATH/classes/policy/event/withdraw.php [ 16 ]
--
#0 /home/matt/events2/application/classes/policy/event/withdraw.php(16): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/even...', 16, Array)
#1 /home/matt/events2/application/classes/model/user.php(69): Policy_Event_Withdraw->execute(Object(Model_User), Array)
#2 /home/matt/events2/application/classes/view/page/event/display.php(134): Model_User->can('event_withdraw', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Display->url_event_withdraw()
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('url_event_withd...', Array)
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('url_event_withd...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('???????????{{#u...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('?????????????</...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??{{^attendees....')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???????<div id=...', Array)
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???????<div id=...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '????')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '????')
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(266): Mustache->_renderTags('<!DOCTYPE html>...')
#14 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!DOCTYPE html>...', Array)
#15 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#16 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#17 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#18 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#19 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Display))
#20 [internal function]: Abstract_Controller_Website->after()
#21 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#22 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#23 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#24 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#25 {main}
2012-11-04 16:23:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:23:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:23:51 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:23:51 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:25:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:25:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:25:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:25:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:28:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:28:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:28:25 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:28:25 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:28:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:28:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:28:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:28:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:28:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:28:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:28:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:28:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:28:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:28:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:28:45 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:28:45 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:41:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:41:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:41:24 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:41:24 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:41:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:41:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:41:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:41:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:43:05 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_RETURN ~ APPPATH/classes/model/enrollment.php [ 107 ]
2012-11-04 16:43:05 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_RETURN ~ APPPATH/classes/model/enrollment.php [ 107 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:43:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:43:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:43:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:43:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:43:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:43:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:43:13 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:43:13 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:46:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:46:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:46:13 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:46:13 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:48:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:48:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:48:49 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:48:49 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:50:06 --- ERROR: Kohana_Exception [ 0 ]: The character property does not exist in the Model_Enrollment class ~ MODPATH/orm/classes/kohana/orm.php [ 621 ]
2012-11-04 16:50:06 --- STRACE: Kohana_Exception [ 0 ]: The character property does not exist in the Model_Enrollment class ~ MODPATH/orm/classes/kohana/orm.php [ 621 ]
--
#0 /home/matt/events2/application/classes/view/page/event/display.php(69): Kohana_ORM->__get('character')
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Display->attendees()
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(769): Mustache->_findVariableInContext('attendees', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('attendees.activ...')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???????<div id=...', Array)
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???????<div id=...')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '????')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '????')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(266): Mustache->_renderTags('<!DOCTYPE html>...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!DOCTYPE html>...', Array)
#10 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#11 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#12 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#13 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#14 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Display))
#15 [internal function]: Abstract_Controller_Website->after()
#16 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#17 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#18 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#19 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#20 {main}
2012-11-04 16:50:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:50:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:50:07 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:50:07 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:50:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:50:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:50:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:50:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:50:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:50:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:50:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:50:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:56:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:56:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:56:59 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:56:59 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:56:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:56:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:56:59 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:56:59 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:58:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:58:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:58:18 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:58:18 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 16:58:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 16:58:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 16:58:55 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 16:58:55 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:04:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:04:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:04:16 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:04:16 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:04:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:04:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:04:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:04:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:04:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:04:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:04:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:04:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:04:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:04:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:04:34 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:04:34 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:05:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:05:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:05:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:05:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:05:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:05:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:05:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:05:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:05:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:05:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:05:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:05:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:05:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:05:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:05:45 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:05:45 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:05:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:05:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:05:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:05:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:06:17 --- ERROR: Database_Exception [ 1452 ]: Cannot add or update a child row: a foreign key constraint fails (`gw2`.`profiles`, CONSTRAINT `profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE) [ INSERT INTO `profiles` (`first_name`, `last_name`, `birthdate`) VALUES ('Testtwo', 'Account', '1980-11-07') ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
2012-11-04 17:06:17 --- STRACE: Database_Exception [ 1452 ]: Cannot add or update a child row: a foreign key constraint fails (`gw2`.`profiles`, CONSTRAINT `profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE) [ INSERT INTO `profiles` (`first_name`, `last_name`, `birthdate`) VALUES ('Testtwo', 'Account', '1980-11-07') ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/matt/events2/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `pr...', false, Array)
#1 /home/matt/events2/modules/orm/classes/kohana/orm.php(1252): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /home/matt/events2/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#3 /home/matt/events2/application/classes/controller/user.php(48): Kohana_ORM->save()
#4 [internal function]: Controller_User->action_edit()
#5 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#6 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#9 {main}
2012-11-04 17:06:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:06:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:06:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:06:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:21:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:21:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:21:55 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:21:55 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:21:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:21:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:21:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:21:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:22:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:22:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:22:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:22:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:22:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:22:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:22:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:22:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:22:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:22:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:22:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:22:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:22:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:22:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:22:43 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:22:43 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:29:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:29:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:29:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:29:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:29:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:29:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:29:43 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:29:43 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:29:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:29:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:29:54 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:29:54 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:30:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:30:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:30:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:30:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:31:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:31:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:31:07 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:31:07 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:31:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:31:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:31:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:31:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:31:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:31:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:31:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:31:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:31:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:31:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:31:15 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:31:15 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:31:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:31:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:31:39 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:31:39 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:31:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:31:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:31:41 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:31:41 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:31:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:31:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:31:55 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:31:55 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:31:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:31:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:31:57 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:31:57 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:31:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:31:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:31:59 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:31:59 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:33:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:33:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:33:54 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:33:54 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:33:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 17:33:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 17:33:55 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 17:33:55 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 17:34:03 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/event.php [ 216 ]
2012-11-04 17:34:03 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/event.php [ 216 ]
--
#0 /home/matt/events2/application/classes/controller/event.php(216): Kohana_Core::error_handler(2048, 'Creating defaul...', '/home/matt/even...', 216, Array)
#1 [internal function]: Controller_Event->action_enroll()
#2 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#3 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#6 {main}
2012-11-04 20:30:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:30:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:30:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:30:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:30:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:30:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:30:57 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:30:57 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:30:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:30:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:30:59 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:30:59 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:31:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:31:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:31:19 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:31:19 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:31:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:31:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:31:59 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:31:59 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:32:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:32:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:32:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:32:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:32:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:32:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:32:42 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:32:42 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:32:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:32:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:32:52 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:32:52 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:32:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:32:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:32:54 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:32:54 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:33:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:33:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:33:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:33:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:33:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:33:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:33:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:33:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:33:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:33:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:33:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:33:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:33:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:33:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:33:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:33:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:33:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:33:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:33:18 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:33:18 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:34:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:34:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:34:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:34:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:34:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:34:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:34:13 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:34:13 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:34:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:34:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:34:16 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:34:16 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:34:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:34:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:34:18 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:34:18 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:34:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:34:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:34:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:34:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:34:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:34:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:34:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:34:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:37:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:37:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:37:56 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:37:56 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:37:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:37:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:37:57 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:37:57 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:37:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:37:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:37:59 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:37:59 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:40:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:40:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:40:02 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:40:02 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:40:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:40:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:40:03 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:40:03 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:40:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:40:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:40:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:40:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:40:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:40:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:40:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:40:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:40:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:40:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:40:31 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:40:31 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:40:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:40:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:40:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:40:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:40:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:40:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:40:33 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:40:33 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:41:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:41:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:41:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:41:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:41:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:41:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:41:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:41:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:41:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:41:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:41:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:41:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:41:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:41:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:41:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:41:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:41:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:41:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:41:31 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:41:31 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:41:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:41:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:41:34 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:41:34 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:41:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:41:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:41:35 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:41:35 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:42:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:42:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:42:09 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:42:09 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:42:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:42:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:42:09 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:42:09 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:42:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:42:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:42:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:42:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:42:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:42:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:42:28 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:42:28 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:42:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:42:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:42:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:42:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:42:33 --- ERROR: ErrorException [ 1 ]: Using $this when not in object context ~ APPPATH/classes/model/status.php [ 25 ]
2012-11-04 20:42:33 --- STRACE: ErrorException [ 1 ]: Using $this when not in object context ~ APPPATH/classes/model/status.php [ 25 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:42:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:42:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:42:33 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:42:33 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:43:26 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '[' ~ APPPATH/classes/model/status.php [ 25 ]
2012-11-04 20:43:26 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '[' ~ APPPATH/classes/model/status.php [ 25 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:43:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:43:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:43:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:43:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:43:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:43:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:43:44 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:43:44 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:44:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:44:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:44:03 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:44:03 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:44:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:44:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:44:41 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:44:41 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:44:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:44:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:44:49 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:44:49 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:44:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:44:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:44:51 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:44:51 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:44:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:44:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:44:53 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:44:53 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:46:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:46:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:46:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:46:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:46:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:46:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:46:15 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:46:15 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:46:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:46:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:46:16 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:46:16 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:46:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:46:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:46:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:46:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:46:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:46:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:46:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:46:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:46:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:46:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:46:50 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:46:50 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:46:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:46:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:46:51 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:46:51 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:46:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:46:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:46:53 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:46:53 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:47:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:47:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:47:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:47:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:47:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:47:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:47:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:47:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:49:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:49:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:49:22 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:49:22 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:49:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:49:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:49:24 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:49:24 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:49:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:49:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:49:25 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:49:25 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:49:30 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Model_Enrollment::is_enrolled() must implement interface Model_ACL_User, instance of Model_Event given, called in /home/matt/events2/application/classes/controller/event.php on line 256 and defined ~ APPPATH/classes/model/enrollment.php [ 82 ]
2012-11-04 20:49:30 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Model_Enrollment::is_enrolled() must implement interface Model_ACL_User, instance of Model_Event given, called in /home/matt/events2/application/classes/controller/event.php on line 256 and defined ~ APPPATH/classes/model/enrollment.php [ 82 ]
--
#0 /home/matt/events2/application/classes/model/enrollment.php(82): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/home/matt/even...', 82, Array)
#1 /home/matt/events2/application/classes/controller/event.php(256): Model_Enrollment::is_enrolled(Object(Model_Event), Object(Database_MySQL_Result))
#2 [internal function]: Controller_Event->action_withdraw()
#3 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#4 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-11-04 20:49:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:49:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:49:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:49:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:49:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:49:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:49:31 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:49:31 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:49:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:49:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:49:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:49:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:51:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:51:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:51:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:51:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:51:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:51:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:51:07 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:51:07 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:51:10 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Model_Enrollment::is_enrolled() must implement interface Model_ACL_User, instance of Model_Event given, called in /home/matt/events2/application/classes/controller/event.php on line 256 and defined ~ APPPATH/classes/model/enrollment.php [ 82 ]
2012-11-04 20:51:10 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Model_Enrollment::is_enrolled() must implement interface Model_ACL_User, instance of Model_Event given, called in /home/matt/events2/application/classes/controller/event.php on line 256 and defined ~ APPPATH/classes/model/enrollment.php [ 82 ]
--
#0 /home/matt/events2/application/classes/model/enrollment.php(82): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/home/matt/even...', 82, Array)
#1 /home/matt/events2/application/classes/controller/event.php(256): Model_Enrollment::is_enrolled(Object(Model_Event), Object(Database_MySQL_Result))
#2 [internal function]: Controller_Event->action_withdraw()
#3 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#4 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-11-04 20:51:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:51:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:51:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:51:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:51:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:51:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:51:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:51:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:51:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:51:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:51:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:51:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:51:25 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Model_Enrollment::is_enrolled() must implement interface Model_ACL_User, instance of Model_Event given, called in /home/matt/events2/application/classes/controller/event.php on line 256 and defined ~ APPPATH/classes/model/enrollment.php [ 82 ]
2012-11-04 20:51:25 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Model_Enrollment::is_enrolled() must implement interface Model_ACL_User, instance of Model_Event given, called in /home/matt/events2/application/classes/controller/event.php on line 256 and defined ~ APPPATH/classes/model/enrollment.php [ 82 ]
--
#0 /home/matt/events2/application/classes/model/enrollment.php(82): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/home/matt/even...', 82, Array)
#1 /home/matt/events2/application/classes/controller/event.php(256): Model_Enrollment::is_enrolled(Object(Model_Event), Object(Database_MySQL_Result))
#2 [internal function]: Controller_Event->action_withdraw()
#3 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#4 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-11-04 20:51:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:51:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:51:25 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:51:25 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:51:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:51:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:51:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:51:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:51:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:51:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:51:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:51:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:51:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:51:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:51:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:51:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:51:31 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Model_Enrollment::is_enrolled() must implement interface Model_ACL_User, instance of Model_Event given, called in /home/matt/events2/application/classes/controller/event.php on line 256 and defined ~ APPPATH/classes/model/enrollment.php [ 82 ]
2012-11-04 20:51:31 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Model_Enrollment::is_enrolled() must implement interface Model_ACL_User, instance of Model_Event given, called in /home/matt/events2/application/classes/controller/event.php on line 256 and defined ~ APPPATH/classes/model/enrollment.php [ 82 ]
--
#0 /home/matt/events2/application/classes/model/enrollment.php(82): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/home/matt/even...', 82, Array)
#1 /home/matt/events2/application/classes/controller/event.php(256): Model_Enrollment::is_enrolled(Object(Model_Event), Object(Database_MySQL_Result))
#2 [internal function]: Controller_Event->action_withdraw()
#3 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#4 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-11-04 20:51:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:51:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:51:31 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:51:31 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:51:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:51:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:51:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:51:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:51:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:51:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:51:34 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:51:34 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:51:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:51:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:51:41 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:51:41 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:52:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:52:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:52:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:52:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:52:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:52:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:52:18 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:52:18 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:52:28 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Model_Enrollment::is_enrolled() must implement interface Model_ACL_User, instance of Model_Event given, called in /home/matt/events2/application/classes/controller/event.php on line 256 and defined ~ APPPATH/classes/model/enrollment.php [ 82 ]
2012-11-04 20:52:28 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Model_Enrollment::is_enrolled() must implement interface Model_ACL_User, instance of Model_Event given, called in /home/matt/events2/application/classes/controller/event.php on line 256 and defined ~ APPPATH/classes/model/enrollment.php [ 82 ]
--
#0 /home/matt/events2/application/classes/model/enrollment.php(82): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/home/matt/even...', 82, Array)
#1 /home/matt/events2/application/classes/controller/event.php(256): Model_Enrollment::is_enrolled(Object(Model_Event), Object(Database_MySQL_Result))
#2 [internal function]: Controller_Event->action_withdraw()
#3 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#4 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-11-04 20:52:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:52:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:52:28 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:52:28 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:52:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:52:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:52:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:52:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:52:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:52:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:52:49 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:52:49 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:52:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:52:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:52:55 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:52:55 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:52:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:52:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:52:56 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:52:56 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:53:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:53:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:53:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:53:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:53:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:53:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:53:33 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:53:33 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:57:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:57:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:57:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:57:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:57:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:57:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:57:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:57:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:57:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:57:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:57:39 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:57:39 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:57:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:57:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:57:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:57:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:57:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:57:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:57:50 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:57:50 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:58:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:58:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:58:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:58:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 20:58:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 20:58:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 20:58:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 20:58:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 21:00:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 21:00:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 21:00:16 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 21:00:16 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 21:00:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 21:00:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 21:00:21 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 21:00:21 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 21:06:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 21:06:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 21:06:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 21:06:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 21:06:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 21:06:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 21:06:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 21:06:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 21:06:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 21:06:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 21:06:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 21:06:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 21:06:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 21:06:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 21:06:31 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 21:06:31 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 21:37:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 21:37:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 21:37:53 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 21:37:53 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 21:37:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 21:37:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 21:37:54 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 21:37:54 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 21:38:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 21:38:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 21:38:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 21:38:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 21:40:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 21:40:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 21:40:02 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 21:40:02 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 21:40:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 21:40:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 21:40:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 21:40:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 21:41:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 21:41:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 21:41:53 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 21:41:53 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 21:42:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 21:42:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 21:42:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 21:42:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 21:42:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 21:42:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 21:42:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 21:42:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 21:42:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 21:42:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 21:42:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 21:42:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 21:44:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 21:44:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 21:44:50 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 21:44:50 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 21:44:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 21:44:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 21:44:56 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 21:44:56 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 21:45:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 21:45:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 21:45:21 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 21:45:21 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 21:45:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 21:45:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: facebox/closelabel.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 21:45:25 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 21:45:25 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-04 21:47:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-04 21:47:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_icon.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-04 21:47:53 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-04 21:47:53 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}