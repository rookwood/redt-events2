<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2012-11-16 15:39:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 15:39:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 15:39:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 15:39:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:29:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:29:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:29:28 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:29:28 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:29:30 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_DOUBLE_ARROW ~ APPPATH/classes/controller/user.php [ 356 ]
2012-11-16 21:29:30 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_DOUBLE_ARROW ~ APPPATH/classes/controller/user.php [ 356 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:29:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:29:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:29:31 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:29:31 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:30:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/form_input_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:30:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/form_input_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:30:16 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:30:16 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:30:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:30:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:30:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:30:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:30:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:30:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:30:19 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:30:19 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:30:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:30:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:32:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:32:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:32:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:32:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:32:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:32:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:32:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:32:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:32:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:32:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:32:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:32:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:33:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:33:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:33:37 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:33:37 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:34:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:34:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:34:02 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:34:02 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:34:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:34:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:34:03 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:34:03 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:34:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:34:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:34:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:34:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:34:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:34:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:34:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:34:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:34:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:34:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:34:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:34:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:34:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:34:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:34:39 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:34:39 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:34:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:34:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:34:57 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:34:57 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:35:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:35:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:35:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:35:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:37:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:37:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:37:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:37:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:37:24 --- ERROR: Kohana_Exception [ 0 ]: View class does not exist: View_email_resetpw ~ MODPATH/kostache/classes/kohana/kostache.php [ 32 ]
2012-11-16 21:37:24 --- STRACE: Kohana_Exception [ 0 ]: View class does not exist: View_email_resetpw ~ MODPATH/kostache/classes/kohana/kostache.php [ 32 ]
--
#0 /home/matt/events2/application/classes/controller/user.php(336): Kohana_Kostache::factory('email/resetpw')
#1 [internal function]: Controller_User->action_resetpw()
#2 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#3 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#6 {main}
2012-11-16 21:37:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:37:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:37:24 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:37:24 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:43:35 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_DOUBLE_ARROW ~ APPPATH/classes/view/email/resetpw.php [ 7 ]
2012-11-16 21:43:35 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_DOUBLE_ARROW ~ APPPATH/classes/view/email/resetpw.php [ 7 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:43:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:43:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:43:35 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:43:35 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:44:00 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_RETURN ~ APPPATH/classes/view/email/resetpw.php [ 9 ]
2012-11-16 21:44:00 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_RETURN ~ APPPATH/classes/view/email/resetpw.php [ 9 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:44:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:44:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:44:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:44:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:44:09 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Kohana_URL::query() must be an array, string given, called in /home/matt/events2/application/classes/view/email/resetpw.php on line 7 and defined ~ SYSPATH/classes/kohana/url.php [ 150 ]
2012-11-16 21:44:09 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Kohana_URL::query() must be an array, string given, called in /home/matt/events2/application/classes/view/email/resetpw.php on line 7 and defined ~ SYSPATH/classes/kohana/url.php [ 150 ]
--
#0 /home/matt/events2/system/classes/kohana/url.php(150): Kohana_Core::error_handler(4096, 'Argument 1 pass...', '/home/matt/even...', 150, Array)
#1 /home/matt/events2/application/classes/view/email/resetpw.php(7): Kohana_URL::query('key', '50rUT4y9Nvi5AjJ...')
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): View_Email_Resetpw->link()
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('link', Array)
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(655): Mustache->_getVariable('link')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(577): Mustache->_renderUnescaped('link', '??', '')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('{', 'link', '??', '')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(266): Mustache->_renderTags('<p>A request to...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<p>A request to...', Array)
#9 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(213): Mustache->render()
#10 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(34): Kohana_Kostache->render()
#11 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Kohana_Kostache_Layout->render()
#12 /home/matt/events2/modules/email/vendor/swiftmailer/lib/classes/Swift/CharacterStream/NgCharacterStream.php(288): Kohana_Kostache->__toString()
#13 /home/matt/events2/modules/email/vendor/swiftmailer/lib/classes/Swift/CharacterStream/NgCharacterStream.php(168): Swift_CharacterStream_NgCharacterStream->write(Object(View_Email_Resetpw))
#14 /home/matt/events2/modules/email/vendor/swiftmailer/lib/classes/Swift/Encoder/QpEncoder.php(147): Swift_CharacterStream_NgCharacterStream->importString(Object(View_Email_Resetpw))
#15 /home/matt/events2/modules/email/vendor/swiftmailer/lib/classes/Swift/Mime/SimpleMimeEntity.php(460): Swift_Encoder_QpEncoder->encodeString(Object(View_Email_Resetpw), 0, 78)
#16 /home/matt/events2/modules/email/vendor/swiftmailer/lib/classes/Swift/Mime/SimpleMimeEntity.php(473): Swift_Mime_SimpleMimeEntity->toString()
#17 /home/matt/events2/modules/email/vendor/swiftmailer/lib/classes/Swift/Mime/SimpleMessage.php(548): Swift_Mime_SimpleMimeEntity->toString()
#18 /home/matt/events2/modules/email/vendor/swiftmailer/lib/classes/Swift/Transport/MailTransport.php(145): Swift_Mime_SimpleMessage->toString()
#19 /home/matt/events2/modules/email/vendor/swiftmailer/lib/classes/Swift/Mailer.php(86): Swift_Transport_MailTransport->send(Object(Swift_Message), Array)
#20 /home/matt/events2/modules/email/classes/kohana/email.php(395): Swift_Mailer->send(Object(Swift_Message), Array)
#21 /home/matt/events2/application/classes/controller/user.php(344): Kohana_Email->send()
#22 [internal function]: Controller_User->action_resetpw()
#23 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#24 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#25 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#26 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#27 {main}
2012-11-16 21:44:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:44:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:44:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:44:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:45:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:45:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:45:16 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:45:16 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:45:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:45:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:45:22 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:45:22 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:46:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:46:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:46:04 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:46:04 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:46:31 --- ERROR: ErrorException [ 8 ]: Undefined variable: user ~ APPPATH/classes/controller/user.php [ 358 ]
2012-11-16 21:46:31 --- STRACE: ErrorException [ 8 ]: Undefined variable: user ~ APPPATH/classes/controller/user.php [ 358 ]
--
#0 /home/matt/events2/application/classes/controller/user.php(358): Kohana_Core::error_handler(8, 'Undefined varia...', '/home/matt/even...', 358, Array)
#1 [internal function]: Controller_User->action_resetpw()
#2 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#3 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#6 {main}
2012-11-16 21:46:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:46:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:46:31 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:46:31 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:47:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/form_input_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:47:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/form_input_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:47:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:47:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:47:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:47:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:47:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:47:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:47:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:47:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:47:33 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:47:33 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:47:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:47:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:47:50 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:47:50 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:47:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: password ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:47:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: password ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:47:59 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:47:59 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:47:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:47:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:47:59 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:47:59 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:48:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:48:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:48:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:48:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:48:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:48:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:48:56 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:48:56 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:49:03 --- ERROR: ErrorException [ 1 ]: Call to undefined method Request::valid_post() ~ APPPATH/classes/controller/user.php [ 367 ]
2012-11-16 21:49:03 --- STRACE: ErrorException [ 1 ]: Call to undefined method Request::valid_post() ~ APPPATH/classes/controller/user.php [ 367 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:49:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:49:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:49:04 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:49:04 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:49:19 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/user.php [ 376 ]
2012-11-16 21:49:19 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/user.php [ 376 ]
--
#0 /home/matt/events2/application/classes/controller/user.php(376): Kohana_Core::error_handler(8, 'Trying to get p...', '/home/matt/even...', 376, Array)
#1 [internal function]: Controller_User->action_password()
#2 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#3 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#6 {main}
2012-11-16 21:49:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:49:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:49:19 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:49:19 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:50:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:50:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:50:03 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:50:03 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:50:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:50:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:50:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:50:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:50:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:50:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:50:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:50:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-16 21:50:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-16 21:50:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-16 21:50:15 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-16 21:50:15 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}