<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2012-11-03 13:14:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:14:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:14:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:14:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:14:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:14:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:14:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:14:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:16:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:16:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:16:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:16:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:18:02 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/controller/user.php [ 316 ]
2012-11-03 13:18:02 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/controller/user.php [ 316 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:18:38 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_ELSE, expecting T_FUNCTION ~ APPPATH/classes/controller/user.php [ 379 ]
2012-11-03 13:18:38 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_ELSE, expecting T_FUNCTION ~ APPPATH/classes/controller/user.php [ 379 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:19:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:19:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:19:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:19:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:21:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:21:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:21:35 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:21:35 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:21:41 --- ERROR: ErrorException [ 1 ]: Class 'Policy_Register' not found ~ APPPATH/classes/controller/user.php [ 95 ]
2012-11-03 13:21:41 --- STRACE: ErrorException [ 1 ]: Class 'Policy_Register' not found ~ APPPATH/classes/controller/user.php [ 95 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:22:22 --- ERROR: ErrorException [ 1 ]: Undefined class constant 'REGISTRATION_COMPLETED' ~ APPPATH/classes/controller/user.php [ 95 ]
2012-11-03 13:22:22 --- STRACE: ErrorException [ 1 ]: Undefined class constant 'REGISTRATION_COMPLETED' ~ APPPATH/classes/controller/user.php [ 95 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:22:59 --- ERROR: ErrorException [ 1 ]: Undefined class constant 'REGISTRATION_CLOSED' ~ APPPATH/classes/controller/user.php [ 101 ]
2012-11-03 13:22:59 --- STRACE: ErrorException [ 1 ]: Undefined class constant 'REGISTRATION_CLOSED' ~ APPPATH/classes/controller/user.php [ 101 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:23:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:23:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:23:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:23:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:23:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:23:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:23:13 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:23:13 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:25:17 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_VARIABLE ~ APPPATH/classes/model/event.php [ 84 ]
2012-11-03 13:25:17 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_VARIABLE ~ APPPATH/classes/model/event.php [ 84 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:25:44 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_VARIABLE ~ APPPATH/classes/model/event.php [ 126 ]
2012-11-03 13:25:44 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_VARIABLE ~ APPPATH/classes/model/event.php [ 126 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:25:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:25:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:25:52 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:25:52 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:29:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:29:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:29:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:29:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:29:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:29:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:29:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:29:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:31:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:31:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:31:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:31:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:31:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:31:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:31:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:31:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:31:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:31:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:31:31 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:31:31 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:31:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:31:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:31:33 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:31:33 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:34:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:34:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:34:39 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:34:39 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:34:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:34:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:34:42 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:34:42 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:35:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:35:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:35:15 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:35:15 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:35:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:35:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:35:35 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:35:35 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:36:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:36:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:36:28 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:36:28 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:36:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: resetpw ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:36:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: resetpw ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:36:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:36:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:38:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:38:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:38:02 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:38:02 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:40:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:40:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:40:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:40:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:40:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:40:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:40:54 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:40:54 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 13:41:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 13:41:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 13:41:25 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 13:41:25 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 15:43:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 15:43:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 15:43:25 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 15:43:25 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 15:43:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: resetpw ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 15:43:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: resetpw ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 15:43:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 15:43:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 15:43:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 15:43:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 15:43:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 15:43:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 15:43:59 --- ERROR: Kohana_Exception [ 0 ]: Please set a salt value for auth. ~ APPPATH/classes/auth.php [ 60 ]
2012-11-03 15:43:59 --- STRACE: Kohana_Exception [ 0 ]: Please set a salt value for auth. ~ APPPATH/classes/auth.php [ 60 ]
--
#0 [internal function]: Auth->hash('freestuff')
#1 /home/matt/events2/modules/orm/classes/kohana/orm.php(1140): call_user_func_array(Array, Array)
#2 /home/matt/events2/modules/orm/classes/kohana/orm.php(664): Kohana_ORM->run_filter('password', 'freestuff')
#3 /home/matt/events2/modules/orm/classes/kohana/orm.php(643): Kohana_ORM->set('password', 'freestuff')
#4 /home/matt/events2/modules/orm/classes/kohana/orm.php(736): Kohana_ORM->__set('password', 'freestuff')
#5 /home/matt/events2/modules/orm/classes/model/auth/user.php(167): Kohana_ORM->values(Array, Array)
#6 /home/matt/events2/application/classes/model/user.php(333): Model_Auth_User->create_user(Array, Array)
#7 /home/matt/events2/application/classes/controller/user.php(121): Model_User->register(Array)
#8 [internal function]: Controller_User->action_register()
#9 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#10 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#13 {main}
2012-11-03 15:44:50 --- ERROR: Kohana_Exception [ 0 ]: Please set a salt value for auth. ~ APPPATH/classes/auth.php [ 60 ]
2012-11-03 15:44:50 --- STRACE: Kohana_Exception [ 0 ]: Please set a salt value for auth. ~ APPPATH/classes/auth.php [ 60 ]
--
#0 [internal function]: Auth->hash('freestuff')
#1 /home/matt/events2/modules/orm/classes/kohana/orm.php(1140): call_user_func_array(Array, Array)
#2 /home/matt/events2/modules/orm/classes/kohana/orm.php(664): Kohana_ORM->run_filter('password', 'freestuff')
#3 /home/matt/events2/modules/orm/classes/kohana/orm.php(643): Kohana_ORM->set('password', 'freestuff')
#4 /home/matt/events2/modules/orm/classes/kohana/orm.php(736): Kohana_ORM->__set('password', 'freestuff')
#5 /home/matt/events2/modules/orm/classes/model/auth/user.php(167): Kohana_ORM->values(Array, Array)
#6 /home/matt/events2/application/classes/model/user.php(333): Model_Auth_User->create_user(Array, Array)
#7 /home/matt/events2/application/classes/controller/user.php(121): Model_User->register(Array)
#8 [internal function]: Controller_User->action_register()
#9 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#10 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#13 {main}
2012-11-03 15:44:59 --- ERROR: Kohana_Exception [ 0 ]: Please set a salt value for auth. ~ APPPATH/classes/auth.php [ 60 ]
2012-11-03 15:44:59 --- STRACE: Kohana_Exception [ 0 ]: Please set a salt value for auth. ~ APPPATH/classes/auth.php [ 60 ]
--
#0 [internal function]: Auth->hash('freestuff')
#1 /home/matt/events2/modules/orm/classes/kohana/orm.php(1140): call_user_func_array(Array, Array)
#2 /home/matt/events2/modules/orm/classes/kohana/orm.php(664): Kohana_ORM->run_filter('password', 'freestuff')
#3 /home/matt/events2/modules/orm/classes/kohana/orm.php(643): Kohana_ORM->set('password', 'freestuff')
#4 /home/matt/events2/modules/orm/classes/kohana/orm.php(736): Kohana_ORM->__set('password', 'freestuff')
#5 /home/matt/events2/modules/orm/classes/model/auth/user.php(167): Kohana_ORM->values(Array, Array)
#6 /home/matt/events2/application/classes/model/user.php(333): Model_Auth_User->create_user(Array, Array)
#7 /home/matt/events2/application/classes/controller/user.php(121): Model_User->register(Array)
#8 [internal function]: Controller_User->action_register()
#9 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#10 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#13 {main}
2012-11-03 15:49:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 15:49:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 15:49:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 15:49:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 15:49:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 15:49:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 15:49:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 15:49:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 15:51:53 --- ERROR: Kohana_Exception [ 0 ]: Please set a salt value for auth. ~ APPPATH/classes/auth.php [ 60 ]
2012-11-03 15:51:53 --- STRACE: Kohana_Exception [ 0 ]: Please set a salt value for auth. ~ APPPATH/classes/auth.php [ 60 ]
--
#0 [internal function]: Auth->hash('freestuff')
#1 /home/matt/events2/modules/orm/classes/kohana/orm.php(1140): call_user_func_array(Array, Array)
#2 /home/matt/events2/modules/orm/classes/kohana/orm.php(664): Kohana_ORM->run_filter('password', 'freestuff')
#3 /home/matt/events2/modules/orm/classes/kohana/orm.php(643): Kohana_ORM->set('password', 'freestuff')
#4 /home/matt/events2/modules/orm/classes/kohana/orm.php(736): Kohana_ORM->__set('password', 'freestuff')
#5 /home/matt/events2/modules/orm/classes/model/auth/user.php(167): Kohana_ORM->values(Array, Array)
#6 /home/matt/events2/application/classes/model/user.php(337): Model_Auth_User->create_user(Array, Array)
#7 /home/matt/events2/application/classes/controller/user.php(121): Model_User->register(Array)
#8 [internal function]: Controller_User->action_register()
#9 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#10 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#13 {main}
2012-11-03 15:56:57 --- ERROR: Kohana_Exception [ 0 ]: The salt property does not exist in the Model_User class ~ MODPATH/orm/classes/kohana/orm.php [ 692 ]
2012-11-03 15:56:57 --- STRACE: Kohana_Exception [ 0 ]: The salt property does not exist in the Model_User class ~ MODPATH/orm/classes/kohana/orm.php [ 692 ]
--
#0 /home/matt/events2/modules/orm/classes/kohana/orm.php(643): Kohana_ORM->set('salt', 'h6OPohwCTCKC2Ct...')
#1 /home/matt/events2/modules/orm/classes/kohana/orm.php(736): Kohana_ORM->__set('salt', 'h6OPohwCTCKC2Ct...')
#2 /home/matt/events2/modules/orm/classes/model/auth/user.php(167): Kohana_ORM->values(Array, Array)
#3 /home/matt/events2/application/classes/model/user.php(339): Model_Auth_User->create_user(Array, Array)
#4 /home/matt/events2/application/classes/controller/user.php(121): Model_User->register(Array)
#5 [internal function]: Controller_User->action_register()
#6 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#7 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#10 {main}
2012-11-03 15:58:33 --- ERROR: Kohana_Exception [ 0 ]: The salt property does not exist in the Model_User class ~ MODPATH/orm/classes/kohana/orm.php [ 692 ]
2012-11-03 15:58:33 --- STRACE: Kohana_Exception [ 0 ]: The salt property does not exist in the Model_User class ~ MODPATH/orm/classes/kohana/orm.php [ 692 ]
--
#0 /home/matt/events2/modules/orm/classes/kohana/orm.php(643): Kohana_ORM->set('salt', '9yuWTps9b4SonsN...')
#1 /home/matt/events2/modules/orm/classes/kohana/orm.php(736): Kohana_ORM->__set('salt', '9yuWTps9b4SonsN...')
#2 /home/matt/events2/modules/orm/classes/model/auth/user.php(167): Kohana_ORM->values(Array, Array)
#3 /home/matt/events2/application/classes/model/user.php(339): Model_Auth_User->create_user(Array, Array)
#4 /home/matt/events2/application/classes/controller/user.php(121): Model_User->register(Array)
#5 [internal function]: Controller_User->action_register()
#6 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#7 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#9 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#10 {main}
2012-11-03 16:03:57 --- ERROR: ErrorException [ 1 ]: Undefined class constant 'message_file' ~ APPPATH/classes/notices.php [ 106 ]
2012-11-03 16:03:57 --- STRACE: ErrorException [ 1 ]: Undefined class constant 'message_file' ~ APPPATH/classes/notices.php [ 106 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 16:04:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 16:04:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 16:04:43 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 16:04:43 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 16:06:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 16:06:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 16:06:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 16:06:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 16:06:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 16:06:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 16:06:53 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 16:06:53 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 16:07:03 --- ERROR: Kohana_Exception [ 0 ]: Please set a salt value for auth. ~ APPPATH/classes/auth.php [ 60 ]
2012-11-03 16:07:03 --- STRACE: Kohana_Exception [ 0 ]: Please set a salt value for auth. ~ APPPATH/classes/auth.php [ 60 ]
--
#0 /home/matt/events2/modules/orm/classes/kohana/auth/orm.php(82): Auth->hash('freestuff')
#1 /home/matt/events2/modules/auth/classes/kohana/auth.php(92): Kohana_Auth_ORM->_login('somehollis@gmai...', 'freestuff', true)
#2 /home/matt/events2/application/classes/controller/user.php(202): Kohana_Auth->login('somehollis@gmai...', 'freestuff', true)
#3 [internal function]: Controller_User->action_login()
#4 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#5 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#8 {main}
2012-11-03 16:08:25 --- ERROR: Kohana_Exception [ 0 ]: Please set a salt value for auth. ~ APPPATH/classes/auth.php [ 60 ]
2012-11-03 16:08:25 --- STRACE: Kohana_Exception [ 0 ]: Please set a salt value for auth. ~ APPPATH/classes/auth.php [ 60 ]
--
#0 /home/matt/events2/modules/orm/classes/kohana/auth/orm.php(82): Auth->hash('freestuff')
#1 /home/matt/events2/modules/auth/classes/kohana/auth.php(92): Kohana_Auth_ORM->_login('somehollis@gmai...', 'freestuff', true)
#2 /home/matt/events2/application/classes/controller/user.php(202): Kohana_Auth->login('somehollis@gmai...', 'freestuff', true)
#3 [internal function]: Controller_User->action_login()
#4 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#5 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#8 {main}
2012-11-03 16:13:29 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_CLASS ~ APPPATH/classes/auth/orm.php [ 3 ]
2012-11-03 16:13:29 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_CLASS ~ APPPATH/classes/auth/orm.php [ 3 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 16:13:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 16:13:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 16:13:54 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 16:13:54 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 16:14:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 16:14:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 16:14:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 16:14:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 16:14:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 16:14:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 16:14:41 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 16:14:41 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 17:20:23 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_STRING, expecting T_VARIABLE ~ APPPATH/classes/controller/user.php [ 5 ]
2012-11-03 17:20:23 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_STRING, expecting T_VARIABLE ~ APPPATH/classes/controller/user.php [ 5 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 17:20:38 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_RETURN ~ APPPATH/classes/controller/user.php [ 10 ]
2012-11-03 17:20:38 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_RETURN ~ APPPATH/classes/controller/user.php [ 10 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 17:23:45 --- ERROR: ErrorException [ 1 ]: Class 'Model_Vendo_User' not found ~ APPPATH/classes/auth.php [ 26 ]
2012-11-03 17:23:45 --- STRACE: ErrorException [ 1 ]: Class 'Model_Vendo_User' not found ~ APPPATH/classes/auth.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 17:24:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 17:24:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 17:24:19 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 17:24:19 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 17:24:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 17:24:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 17:24:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 17:24:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 17:53:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 17:53:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 17:53:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 17:53:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 17:53:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 17:53:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 17:53:48 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 17:53:48 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 17:53:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 17:53:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 17:53:53 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 17:53:53 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 17:55:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 17:55:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 17:55:49 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 17:55:49 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 17:55:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 17:55:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 17:55:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 17:55:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 17:56:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 17:56:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 17:56:09 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 17:56:09 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 17:56:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 17:56:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 17:56:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 17:56:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:01:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:01:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:01:21 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:01:21 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:03:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:03:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:03:50 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:03:50 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:04:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:04:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:04:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:04:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:04:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:04:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:04:04 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:04:04 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:04:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:04:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:04:46 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:04:46 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:04:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:04:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:04:52 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:04:52 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:04:56 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL notice/remove/61616661 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-11-03 18:04:56 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL notice/remove/61616661 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#2 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#3 {main}
2012-11-03 18:06:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:06:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:06:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:06:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:06:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:06:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:06:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:06:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:07:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:07:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:07:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:07:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:08:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:08:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:08:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:08:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:08:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:08:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:08:48 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:08:48 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:09:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:09:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:09:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:09:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:09:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:09:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:09:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:09:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:11:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:11:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:11:31 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:11:31 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:12:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:12:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:12:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:12:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:14:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:14:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:14:44 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:14:44 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:14:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:14:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:14:54 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:14:54 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:15:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:15:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:15:07 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:15:07 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:15:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:15:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:15:54 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:15:54 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:18:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:18:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:18:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:18:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:19:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:19:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:19:45 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:19:45 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:19:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:19:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:19:53 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:19:53 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:19:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:19:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:19:55 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:19:55 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:22:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:22:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:22:16 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:22:16 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:24:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:24:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:24:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:24:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:29:09 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_VARIABLE ~ APPPATH/classes/auth/orm.php [ 30 ]
2012-11-03 18:29:09 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_VARIABLE ~ APPPATH/classes/auth/orm.php [ 30 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:29:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:29:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:29:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:29:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:30:21 --- ERROR: Exception [ 0 ]: Unsupported hash format ~ APPPATH/classes/bcrypt.php [ 79 ]
2012-11-03 18:30:21 --- STRACE: Exception [ 0 ]: Unsupported hash format ~ APPPATH/classes/bcrypt.php [ 79 ]
--
#0 /home/matt/events2/application/classes/auth/orm.php(79): Bcrypt::check('freestuff', NULL)
#1 /home/matt/events2/application/classes/auth/orm.php(30): Auth_ORM->check_password('freestuff')
#2 /home/matt/events2/modules/auth/classes/kohana/auth.php(92): Auth_ORM->_login('somehollis@gmai...', 'freestuff', true)
#3 /home/matt/events2/application/classes/controller/user.php(208): Kohana_Auth->login('somehollis@gmai...', 'freestuff', true)
#4 [internal function]: Controller_User->action_login()
#5 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#6 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#9 {main}
2012-11-03 18:32:33 --- ERROR: Exception [ 0 ]: Unsupported hash format ~ APPPATH/classes/bcrypt.php [ 79 ]
2012-11-03 18:32:33 --- STRACE: Exception [ 0 ]: Unsupported hash format ~ APPPATH/classes/bcrypt.php [ 79 ]
--
#0 /home/matt/events2/application/classes/auth/orm.php(81): Bcrypt::check('freestuff', NULL)
#1 /home/matt/events2/application/classes/auth/orm.php(32): Auth_ORM->check_password('freestuff')
#2 /home/matt/events2/modules/auth/classes/kohana/auth.php(92): Auth_ORM->_login('somehollis@gmai...', 'freestuff', true)
#3 /home/matt/events2/application/classes/controller/user.php(208): Kohana_Auth->login('somehollis@gmai...', 'freestuff', true)
#4 [internal function]: Controller_User->action_login()
#5 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#6 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#9 {main}
2012-11-03 18:34:21 --- ERROR: Exception [ 0 ]: Unsupported hash format ~ APPPATH/classes/bcrypt.php [ 79 ]
2012-11-03 18:34:21 --- STRACE: Exception [ 0 ]: Unsupported hash format ~ APPPATH/classes/bcrypt.php [ 79 ]
--
#0 /home/matt/events2/application/classes/auth/orm.php(83): Bcrypt::check('freestuff', NULL)
#1 /home/matt/events2/application/classes/auth/orm.php(32): Auth_ORM->check_password('freestuff')
#2 /home/matt/events2/modules/auth/classes/kohana/auth.php(92): Auth_ORM->_login('somehollis@gmai...', 'freestuff', true)
#3 /home/matt/events2/application/classes/controller/user.php(208): Kohana_Auth->login('somehollis@gmai...', 'freestuff', true)
#4 [internal function]: Controller_User->action_login()
#5 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#6 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#9 {main}
2012-11-03 18:34:36 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_User::password() ~ APPPATH/classes/auth/orm.php [ 83 ]
2012-11-03 18:34:36 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_User::password() ~ APPPATH/classes/auth/orm.php [ 83 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:35:00 --- ERROR: Exception [ 0 ]: Unsupported hash format ~ APPPATH/classes/bcrypt.php [ 79 ]
2012-11-03 18:35:00 --- STRACE: Exception [ 0 ]: Unsupported hash format ~ APPPATH/classes/bcrypt.php [ 79 ]
--
#0 /home/matt/events2/application/classes/auth/orm.php(83): Bcrypt::check('freestuff', NULL)
#1 /home/matt/events2/application/classes/auth/orm.php(32): Auth_ORM->check_password('freestuff')
#2 /home/matt/events2/modules/auth/classes/kohana/auth.php(92): Auth_ORM->_login('somehollis@gmai...', 'freestuff', true)
#3 /home/matt/events2/application/classes/controller/user.php(208): Kohana_Auth->login('somehollis@gmai...', 'freestuff', true)
#4 [internal function]: Controller_User->action_login()
#5 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#6 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#9 {main}
2012-11-03 18:35:35 --- ERROR: Exception [ 0 ]: Unsupported hash format ~ APPPATH/classes/bcrypt.php [ 79 ]
2012-11-03 18:35:35 --- STRACE: Exception [ 0 ]: Unsupported hash format ~ APPPATH/classes/bcrypt.php [ 79 ]
--
#0 /home/matt/events2/application/classes/auth/orm.php(85): Bcrypt::check('freestuff', NULL)
#1 /home/matt/events2/application/classes/auth/orm.php(32): Auth_ORM->check_password('freestuff')
#2 /home/matt/events2/modules/auth/classes/kohana/auth.php(92): Auth_ORM->_login('somehollis@gmai...', 'freestuff', true)
#3 /home/matt/events2/application/classes/controller/user.php(208): Kohana_Auth->login('somehollis@gmai...', 'freestuff', true)
#4 [internal function]: Controller_User->action_login()
#5 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#6 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#9 {main}
2012-11-03 18:37:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:37:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:37:30 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:37:30 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:37:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:37:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:37:35 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:37:35 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 18:37:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 18:37:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 18:37:41 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 18:37:41 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:45:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:45:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:45:44 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:45:44 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:45:47 --- ERROR: HTTP_Exception_404 [ 404 ]: User edit not found ~ APPPATH/classes/controller/user.php [ 78 ]
2012-11-03 19:45:47 --- STRACE: HTTP_Exception_404 [ 404 ]: User edit not found ~ APPPATH/classes/controller/user.php [ 78 ]
--
#0 [internal function]: Controller_User->action_profile()
#1 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#2 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#4 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#5 {main}
2012-11-03 19:46:49 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '}' ~ APPPATH/classes/view/page/user/edit.php [ 48 ]
2012-11-03 19:46:49 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '}' ~ APPPATH/classes/view/page/user/edit.php [ 48 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:47:38 --- ERROR: ErrorException [ 8 ]: Undefined index: profile ~ APPPATH/classes/policy/user/profile/edit.php [ 9 ]
2012-11-03 19:47:38 --- STRACE: ErrorException [ 8 ]: Undefined index: profile ~ APPPATH/classes/policy/user/profile/edit.php [ 9 ]
--
#0 /home/matt/events2/application/classes/policy/user/profile/edit.php(9): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/even...', 9, Array)
#1 /home/matt/events2/application/classes/model/user.php(69): Policy_User_Profile_Edit->execute(Object(Model_User), Array)
#2 /home/matt/events2/application/classes/controller/user.php(11): Model_User->can('user_profile_ed...')
#3 [internal function]: Controller_User->action_edit()
#4 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#5 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#7 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#8 {main}
2012-11-03 19:49:01 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_PUBLIC ~ APPPATH/classes/model/character.php [ 103 ]
2012-11-03 19:49:01 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_PUBLIC ~ APPPATH/classes/model/character.php [ 103 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:49:28 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '=', expecting ')' ~ APPPATH/classes/model/character.php [ 144 ]
2012-11-03 19:49:28 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '=', expecting ')' ~ APPPATH/classes/model/character.php [ 144 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:49:56 --- ERROR: Kohana_Exception [ 0 ]: The requested route does not exist: character ~ SYSPATH/classes/kohana/route.php [ 106 ]
2012-11-03 19:49:56 --- STRACE: Kohana_Exception [ 0 ]: The requested route does not exist: character ~ SYSPATH/classes/kohana/route.php [ 106 ]
--
#0 /home/matt/events2/system/classes/kohana/route.php(202): Kohana_Route::get('character')
#1 /home/matt/events2/application/classes/view/page/user/edit.php(19): Kohana_Route::url('character', Array)
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_User_Edit->form_action_character_add()
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('form_action_cha...', Array)
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(655): Mustache->_getVariable('form_action_cha...')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(622): Mustache->_renderUnescaped('form_action_cha...', '', '')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(590): Mustache->_renderEscaped('form_action_cha...', NULL, NULL)
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('', 'form_action_cha...', NULL, NULL)
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(228): Mustache->_renderTags('??????</ul>????...')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????</ul>????...')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('?????<fieldset>...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('?????{{#success...')
#12 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<section id="pr...', Array)
#13 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('<section id="pr...')
#14 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '????')
#15 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '????')
#16 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(266): Mustache->_renderTags('<!DOCTYPE html>...')
#17 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!DOCTYPE html>...', Array)
#18 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#19 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#20 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#21 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#22 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_User_Edit))
#23 [internal function]: Abstract_Controller_Website->after()
#24 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_User))
#25 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#26 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#27 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#28 {main}
2012-11-03 19:51:24 --- ERROR: ErrorException [ 1 ]: Access to undeclared static property: Model_Profession::$profession_list ~ APPPATH/classes/view/page/user/edit.php [ 24 ]
2012-11-03 19:51:24 --- STRACE: ErrorException [ 1 ]: Access to undeclared static property: Model_Profession::$profession_list ~ APPPATH/classes/view/page/user/edit.php [ 24 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:52:35 --- ERROR: ErrorException [ 1 ]: Access to undeclared static property: Model_Race::$race_list ~ APPPATH/classes/view/page/user/edit.php [ 37 ]
2012-11-03 19:52:35 --- STRACE: ErrorException [ 1 ]: Access to undeclared static property: Model_Race::$race_list ~ APPPATH/classes/view/page/user/edit.php [ 37 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:53:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:53:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:53:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:53:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:53:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:53:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:53:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:53:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:53:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:53:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:53:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:53:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:53:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:53:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:53:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:53:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:53:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:53:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:53:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:53:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:53:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:53:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:53:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:53:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:53:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:53:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:53:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:53:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:55:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:55:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:55:44 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:55:44 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:55:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:55:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:55:44 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:55:44 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:55:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:55:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:55:44 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:55:44 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:55:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:55:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:55:44 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:55:44 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:55:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:55:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:55:45 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:55:45 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:55:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:55:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:55:45 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:55:45 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:55:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:55:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:55:45 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:55:45 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:55:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:55:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:55:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:55:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:55:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:55:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:55:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:55:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:55:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:55:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:55:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:55:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:55:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:55:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:55:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:55:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:55:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:55:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:55:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:55:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:55:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:55:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:55:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:55:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:55:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:55:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:55:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:55:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:56:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:56:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:56:28 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:56:28 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:56:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:56:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:56:28 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:56:28 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:56:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:56:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:56:28 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:56:28 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:56:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:56:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:56:28 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:56:28 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:56:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:56:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:56:28 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:56:28 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:56:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:56:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:56:28 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:56:28 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:56:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:56:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:56:28 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:56:28 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:56:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:56:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:56:43 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:56:43 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:56:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:56:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:56:43 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:56:43 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:56:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:56:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:56:43 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:56:43 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:56:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:56:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:56:43 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:56:43 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:56:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:56:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:56:43 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:56:43 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:56:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:56:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:56:44 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:56:44 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 19:56:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 19:56:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 19:56:44 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 19:56:44 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:05:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:05:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:05:48 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:05:48 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:05:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:05:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:05:50 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:05:50 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:06:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:06:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:06:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:06:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:06:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:06:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:06:41 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:06:41 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:09:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:09:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:09:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:09:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:10:18 --- ERROR: UnexpectedValueException [ 0 ]: Tried to assign a role that did not exist. ~ APPPATH/classes/model/user.php [ 244 ]
2012-11-03 21:10:18 --- STRACE: UnexpectedValueException [ 0 ]: Tried to assign a role that did not exist. ~ APPPATH/classes/model/user.php [ 244 ]
--
#0 /home/matt/events2/application/classes/controller/user.php(148): Model_User->add_role('verified_user')
#1 [internal function]: Controller_User->action_register()
#2 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#3 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#5 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#6 {main}
2012-11-03 21:10:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:10:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:10:52 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:10:52 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:11:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:11:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:11:16 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:11:16 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:11:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:11:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/mdeia/css/main.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:11:16 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:11:16 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:11:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:11:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/vendor/modernizr-2.6.2.min.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:11:16 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:11:16 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:11:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:11:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:11:16 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:11:16 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:11:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:11:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/css/normalize.css ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:11:16 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:11:16 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:11:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:11:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/plugins.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:11:16 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:11:16 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:11:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:11:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: profile/media/js/main.js ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:11:16 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:11:16 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:16:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:16:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:16:46 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:16:46 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:16:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:16:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:16:51 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:16:51 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:20:32 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Profession::profession_list() ~ APPPATH/classes/model/character.php [ 48 ]
2012-11-03 21:20:32 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Profession::profession_list() ~ APPPATH/classes/model/character.php [ 48 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:21:59 --- ERROR: ErrorException [ 8 ]: Undefined index:  ~ APPPATH/classes/model/character.php [ 49 ]
2012-11-03 21:21:59 --- STRACE: ErrorException [ 8 ]: Undefined index:  ~ APPPATH/classes/model/character.php [ 49 ]
--
#0 /home/matt/events2/application/classes/model/character.php(49): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/even...', 49, Array)
#1 /home/matt/events2/application/classes/controller/character.php(44): Model_Character->create_character(Object(Model_User), Array)
#2 [internal function]: Controller_Character->action_add()
#3 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Character))
#4 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-11-03 21:22:56 --- ERROR: ErrorException [ 8 ]: Undefined index: name ~ APPPATH/classes/model/character.php [ 56 ]
2012-11-03 21:22:56 --- STRACE: ErrorException [ 8 ]: Undefined index: name ~ APPPATH/classes/model/character.php [ 56 ]
--
#0 /home/matt/events2/application/classes/model/character.php(56): Kohana_Core::error_handler(8, 'Undefined index...', '/home/matt/even...', 56, Array)
#1 /home/matt/events2/application/classes/controller/character.php(44): Model_Character->create_character(Object(Model_User), Array)
#2 [internal function]: Controller_Character->action_add()
#3 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Character))
#4 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#6 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#7 {main}
2012-11-03 21:34:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:34:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:34:02 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:34:02 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:44:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:44:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:44:52 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:44:52 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:45:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:45:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:45:03 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:45:03 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:45:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:45:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:45:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:45:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:45:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:45:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:45:16 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:45:16 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:45:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:45:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:45:19 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:45:19 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:45:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:45:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:45:35 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:45:35 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:45:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:45:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:45:37 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:45:37 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:46:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:46:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:46:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:46:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:46:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:46:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:46:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:46:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:47:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:47:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:47:16 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:47:16 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:47:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:47:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:47:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:47:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:49:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:49:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:49:31 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:49:31 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:49:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:49:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:49:50 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:49:50 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:50:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:50:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:50:28 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:50:28 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:50:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:50:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:50:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:50:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:50:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:50:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:50:33 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:50:33 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:51:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:51:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:51:25 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:51:25 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:51:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:51:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:51:33 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:51:33 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:53:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:53:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:53:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:53:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:53:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:53:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:53:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:53:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:53:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:53:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:53:34 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:53:34 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:54:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:54:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:54:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:54:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:54:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:54:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:54:13 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:54:13 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:54:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:54:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:54:18 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:54:18 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:54:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:54:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:54:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:54:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:54:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:54:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:54:24 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:54:24 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:55:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:55:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:55:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:55:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:56:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:56:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:56:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:56:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:57:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:57:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:57:17 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:57:17 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:57:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:57:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:57:18 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:57:18 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:57:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:57:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:57:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:57:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:58:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: edit ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:58:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: edit ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:58:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:58:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:58:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:58:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:58:52 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:58:52 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:59:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:59:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:59:03 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:59:03 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:59:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:59:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:59:44 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:59:44 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 21:59:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 21:59:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 21:59:59 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 21:59:59 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:02:08 --- ERROR: Database_Exception [ 1452 ]: Cannot add or update a child row: a foreign key constraint fails (`gw2`.`profiles`, CONSTRAINT `profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE) [ INSERT INTO `profiles` (`first_name`, `last_name`, `birthdate`) VALUES ('', '', '2012-10-31') ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
2012-11-03 22:02:08 --- STRACE: Database_Exception [ 1452 ]: Cannot add or update a child row: a foreign key constraint fails (`gw2`.`profiles`, CONSTRAINT `profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE) [ INSERT INTO `profiles` (`first_name`, `last_name`, `birthdate`) VALUES ('', '', '2012-10-31') ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/matt/events2/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `pr...', false, Array)
#1 /home/matt/events2/modules/orm/classes/kohana/orm.php(1252): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /home/matt/events2/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#3 /home/matt/events2/application/classes/controller/user.php(48): Kohana_ORM->save()
#4 [internal function]: Controller_User->action_edit()
#5 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#6 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#9 {main}
2012-11-03 22:02:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:02:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:02:09 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:02:09 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:02:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:02:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:02:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:02:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:03:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:03:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:03:07 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:03:07 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:03:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:03:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:03:19 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:03:19 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:03:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:03:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:03:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:03:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:03:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:03:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:03:34 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:03:34 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:03:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:03:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:03:35 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:03:35 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:04:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:04:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:04:34 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:04:34 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:04:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:04:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:04:44 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:04:44 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:04:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:04:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:04:45 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:04:45 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:04:46 --- ERROR: Database_Exception [ 1452 ]: Cannot add or update a child row: a foreign key constraint fails (`gw2`.`profiles`, CONSTRAINT `profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE) [ INSERT INTO `profiles` (`first_name`, `last_name`, `birthdate`) VALUES ('', '', '') ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
2012-11-03 22:04:46 --- STRACE: Database_Exception [ 1452 ]: Cannot add or update a child row: a foreign key constraint fails (`gw2`.`profiles`, CONSTRAINT `profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE) [ INSERT INTO `profiles` (`first_name`, `last_name`, `birthdate`) VALUES ('', '', '') ] ~ MODPATH/profilertoolbar/classes/kohana/database/mysql.php [ 194 ]
--
#0 /home/matt/events2/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `pr...', false, Array)
#1 /home/matt/events2/modules/orm/classes/kohana/orm.php(1252): Kohana_Database_Query->execute(Object(Database_MySQL))
#2 /home/matt/events2/modules/orm/classes/kohana/orm.php(1348): Kohana_ORM->create(NULL)
#3 /home/matt/events2/application/classes/controller/user.php(48): Kohana_ORM->save()
#4 [internal function]: Controller_User->action_edit()
#5 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#6 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#8 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#9 {main}
2012-11-03 22:04:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:04:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:04:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:04:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:05:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:05:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:05:35 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:05:35 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:05:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:05:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:05:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:05:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:05:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:05:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:05:45 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:05:45 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:05:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:05:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:05:49 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:05:49 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:06:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:06:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:06:41 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:06:41 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:06:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:06:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:06:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:06:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:07:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:07:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:07:04 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:07:04 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:07:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:07:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:07:07 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:07:07 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:07:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:07:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:07:08 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:07:08 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:07:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:07:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:07:09 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:07:09 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:07:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:07:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:07:11 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:07:11 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:07:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:07:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:07:14 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:07:14 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:07:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:07:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:07:59 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:07:59 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:08:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:08:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:08:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:08:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:08:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:08:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:08:23 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:08:23 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:08:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:08:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:08:24 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:08:24 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:08:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:08:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:08:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:08:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:08:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:08:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:08:51 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:08:51 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:08:55 --- ERROR: HTTP_Exception_404 [ 404 ]: User fail not found ~ APPPATH/classes/controller/user.php [ 78 ]
2012-11-03 22:08:55 --- STRACE: HTTP_Exception_404 [ 404 ]: User fail not found ~ APPPATH/classes/controller/user.php [ 78 ]
--
#0 [internal function]: Controller_User->action_profile()
#1 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#2 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#3 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#4 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#5 {main}
2012-11-03 22:08:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:08:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:08:56 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:08:56 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 22:09:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 22:09:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 22:09:00 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 22:09:00 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 23:08:12 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_DOUBLE_ARROW ~ APPPATH/classes/view/page/event/index.php [ 31 ]
2012-11-03 23:08:12 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_DOUBLE_ARROW ~ APPPATH/classes/view/page/event/index.php [ 31 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 23:08:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 23:08:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 23:08:12 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 23:08:12 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 23:08:38 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_DOUBLE_ARROW ~ APPPATH/classes/view/page/event/index.php [ 31 ]
2012-11-03 23:08:38 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_DOUBLE_ARROW ~ APPPATH/classes/view/page/event/index.php [ 31 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 23:08:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 23:08:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 23:08:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 23:08:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 23:08:40 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_DOUBLE_ARROW ~ APPPATH/classes/view/page/event/index.php [ 31 ]
2012-11-03 23:08:40 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_DOUBLE_ARROW ~ APPPATH/classes/view/page/event/index.php [ 31 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 23:08:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 23:08:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 23:08:40 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 23:08:40 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 23:09:02 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ';', expecting ')' ~ APPPATH/classes/view/page/event/index.php [ 38 ]
2012-11-03 23:09:02 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ';', expecting ')' ~ APPPATH/classes/view/page/event/index.php [ 38 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 23:09:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 23:09:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 23:09:02 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 23:09:02 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 23:09:19 --- ERROR: UnexpectedValueException [ 0 ]: Tried to check for a role that did not exist. ~ APPPATH/classes/model/user.php [ 168 ]
2012-11-03 23:09:19 --- STRACE: UnexpectedValueException [ 0 ]: Tried to check for a role that did not exist. ~ APPPATH/classes/model/user.php [ 168 ]
--
#0 /home/matt/events2/application/classes/policy/event/add.php(10): Model_User->is_a('verified_user')
#1 /home/matt/events2/application/classes/model/user.php(69): Policy_Event_Add->execute(Object(Model_User), Array)
#2 /home/matt/events2/application/classes/view/page/event/index.php(54): Model_User->can('event_add')
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(795): View_Page_Event_Index->url_event_add()
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(777): Mustache->_findVariableInContext('url_event_add', Array)
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(231): Mustache->_getVariable('url_event_add')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<section id=...', Array)
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<section id=...')
#8 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '????')
#9 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '????')
#10 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(266): Mustache->_renderTags('<!DOCTYPE html>...')
#11 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!DOCTYPE html>...', Array)
#12 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#13 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#14 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#15 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#16 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Index))
#17 [internal function]: Abstract_Controller_Website->after()
#18 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#19 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#20 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#21 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#22 {main}
2012-11-03 23:09:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 23:09:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 23:09:19 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 23:09:19 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 23:09:53 --- ERROR: MustacheException [ 2 ]: Unexpected close section: filters.top ~ MODPATH/kostache/vendor/mustache/Mustache.php [ 332 ]
2012-11-03 23:09:53 --- STRACE: MustacheException [ 2 ]: Unexpected close section: filters.top ~ MODPATH/kostache/vendor/mustache/Mustache.php [ 332 ]
--
#0 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(225): Mustache->_findSection('??????<select n...')
#1 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(263): Mustache->_renderTemplate('??????<select n...')
#2 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('???<section id=...', Array)
#3 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(685): Mustache->render('???<section id=...')
#4 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(566): Mustache->_renderPartial('content', NULL, '????')
#5 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(531): Mustache->_renderTag('>', 'content', NULL, '????')
#6 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(266): Mustache->_renderTags('<!DOCTYPE html>...')
#7 /home/matt/events2/modules/kostache/vendor/mustache/Mustache.php(192): Mustache->_renderTemplate('<!DOCTYPE html>...', Array)
#8 /home/matt/events2/modules/kostache/classes/kohana/kostache/layout.php(43): Mustache->render()
#9 /home/matt/events2/application/classes/abstract/view/layout.php(69): Kohana_Kostache_Layout->render()
#10 /home/matt/events2/modules/kostache/classes/kohana/kostache.php(107): Abstract_View_Layout->render()
#11 /home/matt/events2/system/classes/kohana/response.php(160): Kohana_Kostache->__toString()
#12 /home/matt/events2/application/classes/abstract/controller/website.php(86): Kohana_Response->body(Object(View_Page_Event_Index))
#13 [internal function]: Abstract_Controller_Website->after()
#14 /home/matt/events2/system/classes/kohana/request/client/internal.php(119): ReflectionMethod->invoke(Object(Controller_Event))
#15 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#16 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#17 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#18 {main}
2012-11-03 23:09:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 23:09:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 23:09:53 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 23:09:53 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 23:10:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 23:10:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 23:10:31 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 23:10:31 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 23:10:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 23:10:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 23:10:42 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 23:10:42 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-03 23:10:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-03 23:10:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(109): Kohana_Request->execute()
#1 {main}
2012-11-03 23:10:43 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
2012-11-03 23:10:43 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/classes/kohana/profilertoolbar.php [ 49 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}