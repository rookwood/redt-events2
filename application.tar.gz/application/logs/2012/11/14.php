<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2012-11-14 19:17:27 --- ERROR: ErrorException [ 1 ]: Class 'ProfilerToolbar' not found ~ APPPATH/classes/abstract/view/page.php [ 193 ]
2012-11-14 19:17:27 --- STRACE: ErrorException [ 1 ]: Class 'ProfilerToolbar' not found ~ APPPATH/classes/abstract/view/page.php [ 193 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:17:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:17:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:17:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:17:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:17:42 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:17:42 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:17:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:17:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:17:53 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:17:53 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:17:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:17:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:17:54 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:17:54 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:17:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/form_input_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:17:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/form_input_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:17:57 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:17:57 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:18:06 --- ERROR: ErrorException [ 512 ]: Directory /home/matt/events2/modules/purifier/vendor/htmlpurifier/library/HTMLPurifier/DefinitionCache/Serializer not writable, please chmod to 777 ~ MODPATH/purifier/vendor/htmlpurifier/library/HTMLPurifier/DefinitionCache/Serializer.php [ 179 ]
2012-11-14 19:18:06 --- STRACE: ErrorException [ 512 ]: Directory /home/matt/events2/modules/purifier/vendor/htmlpurifier/library/HTMLPurifier/DefinitionCache/Serializer not writable, please chmod to 777 ~ MODPATH/purifier/vendor/htmlpurifier/library/HTMLPurifier/DefinitionCache/Serializer.php [ 179 ]
--
#0 [internal function]: Kohana_Core::error_handler(512, 'Directory /home...', '/home/matt/even...', 179, Array)
#1 /home/matt/events2/modules/purifier/vendor/htmlpurifier/library/HTMLPurifier/DefinitionCache/Serializer.php(179): trigger_error('Directory /home...', 512)
#2 /home/matt/events2/modules/purifier/vendor/htmlpurifier/library/HTMLPurifier/DefinitionCache/Serializer.php(135): HTMLPurifier_DefinitionCache_Serializer->_testPermissions('/home/matt/even...', 493)
#3 /home/matt/events2/modules/purifier/vendor/htmlpurifier/library/HTMLPurifier/DefinitionCache/Serializer.php(54): HTMLPurifier_DefinitionCache_Serializer->_prepareDir(Object(HTMLPurifier_Config))
#4 /home/matt/events2/modules/purifier/vendor/htmlpurifier/library/HTMLPurifier/DefinitionCache/Decorator.php(57): HTMLPurifier_DefinitionCache_Serializer->cleanup(Object(HTMLPurifier_Config))
#5 /home/matt/events2/modules/purifier/vendor/htmlpurifier/library/HTMLPurifier/DefinitionCache/Decorator/Cleanup.php(37): HTMLPurifier_DefinitionCache_Decorator->cleanup(Object(HTMLPurifier_Config))
#6 /home/matt/events2/modules/purifier/vendor/htmlpurifier/library/HTMLPurifier/Config.php(403): HTMLPurifier_DefinitionCache_Decorator_Cleanup->get(Object(HTMLPurifier_Config))
#7 /home/matt/events2/modules/purifier/vendor/htmlpurifier/library/HTMLPurifier/Config.php(330): HTMLPurifier_Config->getDefinition('HTML', false, false)
#8 /home/matt/events2/modules/purifier/vendor/htmlpurifier/library/HTMLPurifier/Generator.php(65): HTMLPurifier_Config->getHTMLDefinition()
#9 /home/matt/events2/modules/purifier/vendor/htmlpurifier/library/HTMLPurifier.php(127): HTMLPurifier_Generator->__construct(Object(HTMLPurifier_Config), Object(HTMLPurifier_Context))
#10 /home/matt/events2/modules/purifier/classes/purifier/security.php(117): HTMLPurifier->purify('Pellente'sque h...')
#11 /home/matt/events2/application/classes/model/event.php(140): Purifier_Security::xss_clean('Pellente'sque h...')
#12 /home/matt/events2/application/classes/controller/event.php(124): Model_Event->edit_event(Array)
#13 [internal function]: Controller_Event->action_edit()
#14 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_Event))
#15 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#16 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#17 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#18 {main}
2012-11-14 19:18:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:18:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:18:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:18:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:19:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:19:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:19:03 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:19:03 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:19:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:19:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:19:04 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:19:04 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:28:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:28:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:28:04 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:28:04 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:28:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/form_input_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:28:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/form_input_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:28:07 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:28:07 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:28:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:28:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:28:07 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:28:07 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:28:13 --- ERROR: ErrorException [ 8 ]: Use of undefined constant Security - assumed 'Security' ~ APPPATH/classes/model/user.php [ 58 ]
2012-11-14 19:28:13 --- STRACE: ErrorException [ 8 ]: Use of undefined constant Security - assumed 'Security' ~ APPPATH/classes/model/user.php [ 58 ]
--
#0 /home/matt/events2/application/classes/model/user.php(58): Kohana_Core::error_handler(8, 'Use of undefine...', '/home/matt/even...', 58, Array)
#1 /home/matt/events2/modules/orm/classes/kohana/orm.php(1103): Model_User->filters()
#2 /home/matt/events2/modules/orm/classes/kohana/orm.php(664): Kohana_ORM->run_filter('email', 'test2@test.com')
#3 /home/matt/events2/modules/orm/classes/kohana/orm.php(643): Kohana_ORM->set('email', 'test2@test.com')
#4 /home/matt/events2/modules/orm/classes/kohana/orm.php(736): Kohana_ORM->__set('email', 'test2@test.com')
#5 /home/matt/events2/modules/orm/classes/model/auth/user.php(201): Kohana_ORM->values(Array, Array)
#6 /home/matt/events2/application/classes/controller/user.php(44): Model_Auth_User->update_user(Array, Array)
#7 [internal function]: Controller_User->action_edit()
#8 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#9 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#11 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#12 {main}
2012-11-14 19:28:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:28:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:28:13 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:28:13 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:32:05 --- ERROR: ErrorException [ 8 ]: Use of undefined constant Security - assumed 'Security' ~ APPPATH/classes/model/user.php [ 58 ]
2012-11-14 19:32:05 --- STRACE: ErrorException [ 8 ]: Use of undefined constant Security - assumed 'Security' ~ APPPATH/classes/model/user.php [ 58 ]
--
#0 /home/matt/events2/application/classes/model/user.php(58): Kohana_Core::error_handler(8, 'Use of undefine...', '/home/matt/even...', 58, Array)
#1 /home/matt/events2/modules/orm/classes/kohana/orm.php(1103): Model_User->filters()
#2 /home/matt/events2/modules/orm/classes/kohana/orm.php(664): Kohana_ORM->run_filter('email', 'test2@test.com')
#3 /home/matt/events2/modules/orm/classes/kohana/orm.php(643): Kohana_ORM->set('email', 'test2@test.com')
#4 /home/matt/events2/modules/orm/classes/kohana/orm.php(736): Kohana_ORM->__set('email', 'test2@test.com')
#5 /home/matt/events2/modules/orm/classes/model/auth/user.php(201): Kohana_ORM->values(Array, Array)
#6 /home/matt/events2/application/classes/controller/user.php(44): Model_Auth_User->update_user(Array, Array)
#7 [internal function]: Controller_User->action_edit()
#8 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#9 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#10 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#11 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#12 {main}
2012-11-14 19:32:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:32:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:32:05 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:32:05 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:32:26 --- ERROR: ErrorException [ 1 ]: Undefined class constant 'xss_clean' ~ APPPATH/classes/model/user.php [ 58 ]
2012-11-14 19:32:26 --- STRACE: ErrorException [ 1 ]: Undefined class constant 'xss_clean' ~ APPPATH/classes/model/user.php [ 58 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:32:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:32:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:32:26 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:32:26 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:32:45 --- ERROR: ErrorException [ 1 ]: Undefined class constant 'xss_clean' ~ APPPATH/classes/model/user.php [ 58 ]
2012-11-14 19:32:45 --- STRACE: ErrorException [ 1 ]: Undefined class constant 'xss_clean' ~ APPPATH/classes/model/user.php [ 58 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:32:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:32:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:32:46 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:32:46 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:35:51 --- ERROR: ErrorException [ 1 ]: Undefined class constant 'xss_clean' ~ APPPATH/classes/model/user.php [ 58 ]
2012-11-14 19:35:51 --- STRACE: ErrorException [ 1 ]: Undefined class constant 'xss_clean' ~ APPPATH/classes/model/user.php [ 58 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:35:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:35:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:35:52 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:35:52 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:36:03 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Purifier_Security::xss_clean(), called in /home/matt/events2/application/classes/model/user.php on line 58 and defined ~ MODPATH/purifier/classes/purifier/security.php [ 100 ]
2012-11-14 19:36:03 --- STRACE: ErrorException [ 2 ]: Missing argument 1 for Purifier_Security::xss_clean(), called in /home/matt/events2/application/classes/model/user.php on line 58 and defined ~ MODPATH/purifier/classes/purifier/security.php [ 100 ]
--
#0 /home/matt/events2/modules/purifier/classes/purifier/security.php(100): Kohana_Core::error_handler(2, 'Missing argumen...', '/home/matt/even...', 100, Array)
#1 /home/matt/events2/application/classes/model/user.php(58): Purifier_Security::xss_clean()
#2 /home/matt/events2/modules/orm/classes/kohana/orm.php(1103): Model_User->filters()
#3 /home/matt/events2/modules/orm/classes/kohana/orm.php(664): Kohana_ORM->run_filter('email', 'test2@test.com')
#4 /home/matt/events2/modules/orm/classes/kohana/orm.php(643): Kohana_ORM->set('email', 'test2@test.com')
#5 /home/matt/events2/modules/orm/classes/kohana/orm.php(736): Kohana_ORM->__set('email', 'test2@test.com')
#6 /home/matt/events2/modules/orm/classes/model/auth/user.php(201): Kohana_ORM->values(Array, Array)
#7 /home/matt/events2/application/classes/controller/user.php(44): Model_Auth_User->update_user(Array, Array)
#8 [internal function]: Controller_User->action_edit()
#9 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#10 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#13 {main}
2012-11-14 19:36:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:36:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:36:03 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:36:03 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:36:35 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Purifier_Security::xss_clean(), called in /home/matt/events2/application/classes/model/user.php on line 58 and defined ~ MODPATH/purifier/classes/purifier/security.php [ 100 ]
2012-11-14 19:36:35 --- STRACE: ErrorException [ 2 ]: Missing argument 1 for Purifier_Security::xss_clean(), called in /home/matt/events2/application/classes/model/user.php on line 58 and defined ~ MODPATH/purifier/classes/purifier/security.php [ 100 ]
--
#0 /home/matt/events2/modules/purifier/classes/purifier/security.php(100): Kohana_Core::error_handler(2, 'Missing argumen...', '/home/matt/even...', 100, Array)
#1 /home/matt/events2/application/classes/model/user.php(58): Purifier_Security::xss_clean()
#2 /home/matt/events2/modules/orm/classes/kohana/orm.php(1103): Model_User->filters()
#3 /home/matt/events2/modules/orm/classes/kohana/orm.php(664): Kohana_ORM->run_filter('email', 'test2@test.com')
#4 /home/matt/events2/modules/orm/classes/kohana/orm.php(643): Kohana_ORM->set('email', 'test2@test.com')
#5 /home/matt/events2/modules/orm/classes/kohana/orm.php(736): Kohana_ORM->__set('email', 'test2@test.com')
#6 /home/matt/events2/modules/orm/classes/model/auth/user.php(201): Kohana_ORM->values(Array, Array)
#7 /home/matt/events2/application/classes/controller/user.php(44): Model_Auth_User->update_user(Array, Array)
#8 [internal function]: Controller_User->action_edit()
#9 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#10 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#13 {main}
2012-11-14 19:36:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:36:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:36:36 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:36:36 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:37:31 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Purifier_Security::xss_clean(), called in /home/matt/events2/application/classes/model/user.php on line 58 and defined ~ MODPATH/purifier/classes/purifier/security.php [ 100 ]
2012-11-14 19:37:31 --- STRACE: ErrorException [ 2 ]: Missing argument 1 for Purifier_Security::xss_clean(), called in /home/matt/events2/application/classes/model/user.php on line 58 and defined ~ MODPATH/purifier/classes/purifier/security.php [ 100 ]
--
#0 /home/matt/events2/modules/purifier/classes/purifier/security.php(100): Kohana_Core::error_handler(2, 'Missing argumen...', '/home/matt/even...', 100, Array)
#1 /home/matt/events2/application/classes/model/user.php(58): Purifier_Security::xss_clean()
#2 /home/matt/events2/modules/orm/classes/kohana/orm.php(1103): Model_User->filters()
#3 /home/matt/events2/modules/orm/classes/kohana/orm.php(664): Kohana_ORM->run_filter('email', 'test2@test.com')
#4 /home/matt/events2/modules/orm/classes/kohana/orm.php(643): Kohana_ORM->set('email', 'test2@test.com')
#5 /home/matt/events2/modules/orm/classes/kohana/orm.php(736): Kohana_ORM->__set('email', 'test2@test.com')
#6 /home/matt/events2/modules/orm/classes/model/auth/user.php(201): Kohana_ORM->values(Array, Array)
#7 /home/matt/events2/application/classes/controller/user.php(44): Model_Auth_User->update_user(Array, Array)
#8 [internal function]: Controller_User->action_edit()
#9 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#10 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#13 {main}
2012-11-14 19:37:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:37:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:37:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:37:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:40:53 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Purifier_Security::xss_clean(), called in /home/matt/events2/application/classes/model/user.php on line 58 and defined ~ MODPATH/purifier/classes/purifier/security.php [ 100 ]
2012-11-14 19:40:53 --- STRACE: ErrorException [ 2 ]: Missing argument 1 for Purifier_Security::xss_clean(), called in /home/matt/events2/application/classes/model/user.php on line 58 and defined ~ MODPATH/purifier/classes/purifier/security.php [ 100 ]
--
#0 /home/matt/events2/modules/purifier/classes/purifier/security.php(100): Kohana_Core::error_handler(2, 'Missing argumen...', '/home/matt/even...', 100, Array)
#1 /home/matt/events2/application/classes/model/user.php(58): Purifier_Security::xss_clean()
#2 /home/matt/events2/modules/orm/classes/kohana/orm.php(1103): Model_User->filters()
#3 /home/matt/events2/modules/orm/classes/kohana/orm.php(664): Kohana_ORM->run_filter('email', 'test2@test.com')
#4 /home/matt/events2/modules/orm/classes/kohana/orm.php(643): Kohana_ORM->set('email', 'test2@test.com')
#5 /home/matt/events2/modules/orm/classes/kohana/orm.php(736): Kohana_ORM->__set('email', 'test2@test.com')
#6 /home/matt/events2/modules/orm/classes/model/auth/user.php(201): Kohana_ORM->values(Array, Array)
#7 /home/matt/events2/application/classes/controller/user.php(44): Model_Auth_User->update_user(Array, Array)
#8 [internal function]: Controller_User->action_edit()
#9 /home/matt/events2/system/classes/kohana/request/client/internal.php(116): ReflectionMethod->invoke(Object(Controller_User))
#10 /home/matt/events2/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#11 /home/matt/events2/system/classes/kohana/request.php(1154): Kohana_Request_Client->execute(Object(Request))
#12 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#13 {main}
2012-11-14 19:40:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:40:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:40:53 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:40:53 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:41:10 --- ERROR: ErrorException [ 1 ]: Undefined class constant 'xss_clean' ~ APPPATH/classes/model/user.php [ 58 ]
2012-11-14 19:41:10 --- STRACE: ErrorException [ 1 ]: Undefined class constant 'xss_clean' ~ APPPATH/classes/model/user.php [ 58 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:41:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:41:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:41:10 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:41:10 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:42:43 --- ERROR: ErrorException [ 1 ]: Undefined class constant 'xss_clean' ~ APPPATH/classes/model/user.php [ 62 ]
2012-11-14 19:42:43 --- STRACE: ErrorException [ 1 ]: Undefined class constant 'xss_clean' ~ APPPATH/classes/model/user.php [ 62 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:42:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:42:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:42:43 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:42:43 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:43:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/form_input_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:43:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/form_input_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:43:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:43:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:43:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:43:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:43:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:43:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:43:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:43:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:43:43 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:43:43 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:54:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:54:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:54:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:54:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:54:59 --- ERROR: ErrorException [ 1 ]: Call to undefined method Kohana::config() ~ MODPATH/markdown/classes/kohana/markdown.php [ 198 ]
2012-11-14 19:54:59 --- STRACE: ErrorException [ 1 ]: Call to undefined method Kohana::config() ~ MODPATH/markdown/classes/kohana/markdown.php [ 198 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:55:04 --- ERROR: ErrorException [ 1 ]: Call to undefined method Kohana::config() ~ MODPATH/markdown/classes/kohana/markdown.php [ 198 ]
2012-11-14 19:55:04 --- STRACE: ErrorException [ 1 ]: Call to undefined method Kohana::config() ~ MODPATH/markdown/classes/kohana/markdown.php [ 198 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:56:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:56:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:56:32 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:56:32 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:56:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:56:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:56:34 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:56:34 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:57:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:57:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:57:01 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:57:01 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:57:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:57:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:57:18 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:57:18 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:57:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:57:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:57:33 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:57:33 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 19:57:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 19:57:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 19:57:48 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 19:57:48 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 20:00:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 20:00:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 20:00:06 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 20:00:06 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 20:00:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 20:00:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 20:00:18 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 20:00:18 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 20:00:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 20:00:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 20:00:20 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 20:00:20 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 20:00:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 20:00:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 20:00:21 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 20:00:21 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 20:00:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 20:00:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 20:00:22 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 20:00:22 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 20:00:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 20:00:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 20:00:24 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 20:00:24 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 20:03:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 20:03:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 20:03:35 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 20:03:35 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 20:03:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 20:03:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 20:03:37 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 20:03:37 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 20:05:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 20:05:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 20:05:50 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 20:05:50 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 20:13:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 20:13:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 20:13:47 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 20:13:47 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 20:14:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 20:14:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 20:14:25 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 20:14:25 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 20:14:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 20:14:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/comment_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 20:14:25 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 20:14:25 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 20:14:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/form_input_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 20:14:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: media/img/form_input_bg.png ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 20:14:27 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 20:14:27 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 20:15:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 20:15:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 20:15:09 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 20:15:09 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 20:16:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 20:16:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 20:16:54 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 20:16:54 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 20:17:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 20:17:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 20:17:43 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 20:17:43 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 20:17:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 20:17:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 20:17:58 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 20:17:58 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 20:18:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 20:18:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 20:18:29 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 20:18:29 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 20:18:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 20:18:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 20:18:38 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 20:18:38 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-11-14 20:20:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
2012-11-14 20:20:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1142 ]
--
#0 /home/matt/events2/public_html/index.php(115): Kohana_Request->execute()
#1 {main}
2012-11-14 20:20:02 --- ERROR: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
2012-11-14 20:20:02 --- STRACE: ErrorException [ 1 ]: Call to a member function route() on a non-object ~ MODPATH/profilertoolbar/views/PTB/items/route.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}