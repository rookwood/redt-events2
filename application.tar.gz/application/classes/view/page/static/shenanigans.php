<?php defined('SYSPATH') or die('No direct script access.');

class View_Page_Static_Shenanigans extends Abstract_View_Page {

	public $page_title = 'Shenanigans Night';

}