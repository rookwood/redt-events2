<?php defined('SYSPATH') or die('No direct access allowed.');

class Controller_Welcome extends Controller {

	public function action_index()
	{
		$query = 'Cha';
		print_r(ORM::factory('character')->where('name', 'LIKE', '%'.$query.'%')->find_all());
		ob_flush();
	}


}