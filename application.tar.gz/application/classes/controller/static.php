<?php defined('SYSPATH') or die('No direct script access.');

class Controller_Static extends Abstract_Controller_Website {

	public function action_news(){}
	
	public function action_faq(){}
	
	public function action_shenanigans(){}
}