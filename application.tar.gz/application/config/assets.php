<?php defined('SYSPATH') or die('No direct script access.');

return array (
	'default' => array(
		array('script', '//ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js', 'body'),
		array('script', '//ajax.googleapis.com/ajax/libs/jqueryui/1.9.0/jquery-ui.min.js', 'body', 10),
		array('style',  '//media/css/styles.css', 'head'),
	),	
);