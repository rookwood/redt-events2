<?php
return array(	'salt'       => 'secretsalt',
	'expiration' => Date::WEEK,);