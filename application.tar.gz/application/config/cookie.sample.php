<?php
return array(	'salt'       => 'salt',
	'expiration' => Date::WEEK,);